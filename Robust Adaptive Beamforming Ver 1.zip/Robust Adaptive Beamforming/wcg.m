function f = wcg (PP1,PP2,w,u,ep,L,II)
%II = ones(size(ep))';
w1=w+u*PP2*L;
f=real(PP1'*w1)-ep'*norm(w1)-II;
end

