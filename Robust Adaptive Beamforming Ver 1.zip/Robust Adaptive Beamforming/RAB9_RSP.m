clear all;
close all;
M = 5;                    % Elements in array
d = 1/2;                  % sensor spacing half wavelength wrt wc
N = 1000;                 % number of samples  
Ndb	= -30;             % kind of noise level in dB
f1 = 0.01 ;               % frequancy of S1
f2 = 0.02 ;               % frequancy of S2
f3 = 0.03;                % frequancy of S2
A1 =10^(0/20);            % Amplitude of sinusoid (required)
A2 =10^(10/20);           % Amplitude of first sinterfernce (10 db stronger) 
A3 =10^(10/20);           % Amplitude of second sinterfernce (10 db stronger)  
L = 3;                    % number of sources
theta1 = 0;               % Direction of arrival of interested signal
theta2 = pi/4;            % Second direction of arrival for first interfernce
theta3 = pi/6;            % thired direction of arrival for second interfernce 
zeta = 1;                 % inverse matrix initialization
Ln = 1;                   % define the forgetting factor  
ff = 0.97;                % Forgetting factorof subspace traking algorithm
En = orth(rand(M,M-L)+i*rand(M,M-L)); % inialaize eigenvector matrix with orthogonal matrix
Es = orth(rand(M,L)+i*rand(M,L));     % inialaize eigenvector matrix with orthogonal matrix
%EV = (10^(Ndb/20)/sqrt(2)/M)*eye(M); % inialaize eigenvalues matrix 
ep1 = 1;                  % tolerance value for the proposed
ep2 = 1;                  % tolerance value for the robust with eigendecomposition
ep3 = 3;                 % tolerance value for SOCP
G = 0;                    % initalize QI constraint gradient
wp = zeros(M,1);          % initialize the conventional capon 
IR = zeta*eye(M);         % initalize the inverse autocorrelation matrix
Rs = (1/zeta)*eye(M);     % initalize the inverse autocorrelation matrix
alfa1 = 0.01;             % initalize the coffeiant of step-size 
VL = 1;                   % proposed Variable loading Technique 
misang = -0.03*pi;         % mismatch angle
%misang = 0;
diagl = 0;                % fixed diagonal loadingterm for SOCP
%define source signal
s1	= A1*cos(2*pi*f1*(1:N)) ;
s2	= A2*sign(cos(2*pi*f2*(1:N)));
%s3	= A3*(cos(2*pi*f3*(1:N))) ;
s3	= A3*sign(randn(1,N)) ;

S	= [ s1 ; s2 ; s3 ] ;                %source signal with dimention L*N rows of signal
noiseamp = 10^(Ndb/20)/sqrt(2);      %noise amplitude for complex noise
V=noiseamp*randn(M,N)+i*noiseamp*randn(M,N); %noise process generaation 

%Intialize steering vectors
P=zeros(M,L);  

%generate steering vectors
for j=1:M
   P(j,1)=exp((j-1)*i*2*pi*d*sin(theta1));
end
for j=1:M
   P(j,2)=exp((j-1)*i*2*pi*d*sin(theta2));
end
for j=1:M
   P(j,3)=exp((j-1)*i*2*pi*d*sin(theta3));
end
Pa = P(:,1);  %save correct DOA
% generate recived signal vectors from antenna array 
X = P*S+V ;%recived signal with dimention M*N
H = [A1*P(:,1), A2*P(:,2), A3*P(:,3)];
%add mismatch error to steering vector by 
for j=1:M
   P(j,1)=exp((j-1)*i*2*pi*d*sin(theta1+misang));
end
 
as = (P(:,1)/norm(P(:,1)))*M; %normalize the presumed steering vector for SOCP
%P(:,1) = as;
%Conventional  Beamformer 
R_v = 10^(Ndb/10)*eye(M,M);        %noise matrix
IR_v= inv(R_v);
pwc = 1/((P(:,1))'*IR_v*(P(:,1))); %output power 
Ko = P(:,1)'*IR_v*pwc;             %Optimal gain vector (Capon beamformer) 

%adaptive beamforming start now (capon beamforming)
% initialaize the beamformer
wc = P(:,1)/M; % conventional beamformer;
%H = [A1*P(:,1), A2*P(:,2), A3*P(:,3)]; %generate mixing matrix which including the amplitudes
Pr = P(:,1);  %initialize the robust steering vector; 
%C =P(:,1); 
%Pr = zeros(M,1);
Gr = IR*Pr;   %initialize the gradient; 
%Pc1 = eye(M)-(C*C')/real((C'*C)); %Projection matrix for conventional capon beamforming
%Pc2 = eye(M)-(Pr*Pr')/real((Pr'*Pr)); 
for k = 1:N 
    r = X(:,k); %take one snapshot receiving vector
    Rs  = Ln*Rs + r*r';                     % autocorrelation matrix of recived signal  
    dem = real(1/(Ln+ r'*IR*r));            % 
    Kn = dem*IR*r;                          % Kalaman gain        
    IR = (1/Ln)*(IR - Kn*r'*IR);            % update inverse of Autocorrolation matrix 
    D = Gr+G;                               % update the previous gradient with Diagonal loading term
    mu = real((alfa1*D'*D)/(real(D'*IR*D)+0.0000001)); % update the step size 
    Gr = IR'*Pr;                            % Calculate the gradient 
    pp1 = Pr-P(:,1);                        % it must satisfy the constraint 
    Pr1= Pr - mu*Gr;                        % update the robust steering vector w/t QI constraint  
    pp2 = Pr1-P(:,1);                       % calculate the difference with known steering vector
    %if k~=1
    if (norm(pp2)^2)> ep1                   % check for QC condition on pp vector1  
                cc = pp2'*pp2-ep1;                                    % positive
                bb = 2*mu*real(pp2'*pp1);                             % positive
                aa = (mu^2)*(pp1'*pp1);                               % positive
                landa = (bb-real(((bb^2)-(4*aa*cc))^0.5))/(2*aa);     % estimate diagonal Loading term
                Pr1 = Pr -mu*Gr-mu*landa*pp1;                         % apply Quadritic inquallity constrain
                G = landa*pp1;                                        % gradient of QC term to be added in advance  

            else
        G = 0;
    end
    %end
    Pr = Pr1;
    %performing robust of compared algorithm   
    %IRs = inv(Rs);
    [U,D] = eig(Rs);                                    % get eigen vectors and values of autocorrelation matrix
    gm = real(diag(D));                                 % get eigenvalues in one vector
    z = U'*P(:,1);                                      % get vecotr to estimate the diagonal loading term
    landa1 = newton1(z,gm,ep2,P(:,1));                  % get the diagonal loading term by newton method
    Pd = P(:,1) - (inv(eye(M)+landa1*Rs))*P(:,1);       % get equivalent steering vector with uncertainities
    
    
    Es = NOOjacom(r,Es,1,0.001,0.01);                  % Signal subspace tracking
    En = NOOjacom(r,En,-1,0.001,0.01);                  % noise subspace tracking 
    %En = flipdim(En,2);
    Es = flipdim(Es,2);
    E = [En Es];                                        % combine signal subspaces
    EV = real(diag(E'*Rs*E));               
    E1 = E'*P(:,1);                                     % get vecotr to estimate the diagonal loading term
    landa2 = newton1(E1,EV,ep2,P(:,1));                 % get the diagonal loading term by newton method
    Ps = P(:,1) - (inv(eye(M)+landa2*Rs))*P(:,1);       % get equivalent steering vector with uncertainities
    
    if mod(k-1,10)==0
    %SOCP using SeDuMi software package 
       [wo] = robustbeam(Rs,as,ep3,diagl);
    end
    %Power
    pwp(k) = 1/(real(P(:,1)'*IR*P(:,1)));               % output power of standared beamformer
    pwr(k) = 1/(real(Pr'*IR*Pr));                       % output power of robust beamformer
    pwd(k) = 1/(real(Pd'*IR*Pd));                       % 
    pws(k) = 1/(real(Ps'*IR*Ps));   
    pwo(k) = real(wo'*Rs*wo);                           % o/p power of SOCP
    
    
    %Beamformer
    wr = (IR*Pr)*pwr(k);                     % robust Capon beamforming
    wp = (IR*P(:,1))*pwp(k);                 % conventional capon beamformer 
    wd = (IR*Pd)*pwd(k);                     % robust2 capon beamforming
    ws = (IR*Ps)*pws(k);
    
    %Array Gain
    gnp(k) = ((abs( wp'*Pa)).^2)/(real(wp'*R_v*wp));
    gnr(k) = ((abs( wr'*Pa)).^2)/(real(wr'*R_v*wr));
    gnd(k) = ((abs( wd'*Pa)).^2)/(real(wd'*R_v*wd));
    gns(k) = ((abs( ws'*Pa)).^2)/(real(ws'*R_v*ws));
    gno(k) = ((abs( wo'*Pa)).^2)/(real(wo'*R_v*wo)); 
    
    %SINR
    SINRP(k) = SINRF(wp,H,Ndb,1);             % SINR of standared capon beamformer 
    SINRR(k) = SINRF(wr,H,Ndb,1);             % SINR of robust capon beamformer 
    SINRD(k) = SINRF(wd,H,Ndb,1);
    SINRS(k) = SINRF(ws,H,Ndb,1);
    SINRO(k) = SINRF(wo,H,Ndb,1);
    %Output
    op1(k) = real(wp'*X(:,k));               % o/p signal of capon beamforming
    op2(k) = real(wc'*X(:,k));               % o/p signal of conventional beamforming
    op3(k) = real(wr'*X(:,k));               % o/p robust of capon beamforming
    op4(k) = real(wd'*X(:,k));               % o/p of robust2 beamforming
    op5(k) = real(ws'*X(:,k));  
    op6(k) = real(wo'*X(:,k)); 
    %MSE
    msep(k) = (op1(k)-s1(k))^2;              % MSE of capon beamforming
    msec(k) = (op2(k)-s1(k))^2;              % MSE of conventional beamforming  
    mser(k) = (op3(k)-s1(k))^2;              % MSE of robust capon beamforming
    msed(k) = (op4(k)-s1(k))^2;              % MSE of robust2 capon beamforming
    mses(k) = (op5(k)-s1(k))^2;
    mseo(k) = (op6(k)-s1(k))^2;
end

%Smoothing
%Butter worht smoothing Filter
[filt_num,filt_den] = butter(1,10^(-2));
%SINR
SINRP = 10*log10(abs(filtfilt(filt_num,filt_den,SINRP)));
SINRR = 10*log10(abs(filtfilt(filt_num,filt_den,SINRR)));
SINRD = 10*log10(abs(filtfilt(filt_num,filt_den,SINRD)));
SINRC = 10*log10(abs(SINRF(wc,H,Ndb,1)));    % Conventional SINR
SINRS = 10*log10(abs(filtfilt(filt_num,filt_den,SINRS)));
SINRO = 10*log10(abs(filtfilt(filt_num,filt_den,SINRO)));

%MSE
msep = 10*log10(abs(filtfilt(filt_num,filt_den,msep)));
msec = 10*log10(abs(filtfilt(filt_num,filt_den,msec)));
mser = 10*log10(abs(filtfilt(filt_num,filt_den,mser)));
msed = 10*log10(abs(filtfilt(filt_num,filt_den,msed)));
mses = 10*log10(abs(filtfilt(filt_num,filt_den,mses)));
mseo = 10*log10(abs(filtfilt(filt_num,filt_den,mseo)));

%Power
pwp = 10*log10(abs(filtfilt(filt_num,filt_den,pwp)));
pwr = 10*log10(abs(filtfilt(filt_num,filt_den,pwr)));
pwd = 10*log10(abs(filtfilt(filt_num,filt_den,pwd)));
pwc = 10*log10(abs(pwc));
pws = 10*log10(abs(filtfilt(filt_num,filt_den,pws)));
pwo = 10*log10(abs(filtfilt(filt_num,filt_den,pwo)));

%array gain
gnp = 10*log10(abs(filtfilt(filt_num,filt_den,gnp)));
gnr = 10*log10(abs(filtfilt(filt_num,filt_den,gnr)));
gnd = 10*log10(abs(filtfilt(filt_num,filt_den,gnd)));
gns = 10*log10(abs(filtfilt(filt_num,filt_den,gns)));
gno = 10*log10(abs(filtfilt(filt_num,filt_den,gno)));

%plot array gain
figure(1);
gnp = plot(1:N, gnp,'r');
hold on;
gnd = plot(1:N, gnd,'g');
hold on;
gns = plot(1:N,gns ,'b');
hold on;
gnr = plot(1:N, gnr,'k');
hold on;
gno = plot(1:N, gno,'m');


legend([gnp gnd gns gno gnr],'Standared Capon','Robust Capon (Batch)','Robust Capon (SS)','Robust (SOCP)','Proposed');
xlabel('Iterations (n)');
ylabel('Array Gain (dB)');
title('Array Gain'); 

%Plot mse
figure(2);
hmp = plot(1:N, msep,'r');
hold on;
hmd = plot(1:N, msed,'g');
hold on;
hms = plot(1:N, mses,'b');
hold on;
hmr = plot(1:N, mser,'k');
hold on;
hmo = plot(1:N, mseo,'m');


legend([hmp hmd hms hmo hmr],'Standared Capon','Robust Capon (Batch)','Robust Capon (SS)','Robust (SOCP)','Proposed');
xlabel('Iterations (n)');
ylabel('MSE (dB)');
title('Mean Squared Error'); 
%Plot SINR
figure(3);
hsp = plot(1:N, SINRP,'r'); 
hold on;
hsd = plot(1:N, SINRD,'g');
hold on;
hss = plot(1:N, SINRS,'b');
hold on;
hsr = plot(1:N, SINRR,'k');
hold on;
hso = plot(1:N, SINRO,'m');

xlabel('Iterations (n)');
ylabel('SINR (dB)');
title(' Signal-to-Interference+Noise Ratio'); 
legend([hsp hsd hss hso hsr],'Standared Capon','Robust Capon (Batch)','Robust Capon (SS)','Robust (SOCP)','Proposed');

%Plot power
figure(4);
hwp = plot(1:N, pwp,'r');
hold on;
hwd = plot(1:N, pwd,'g');
hold on;
hws = plot(1:N, pws,'b');
hold on;
hwr = plot(1:N, pwr,'k');
hold on;
hwo = plot(1:N, pwo,'m');

xlabel('Iterations (n)');
ylabel('SOI Power (dB)');
title(' Signal of Interest Power'); 
legend([hwp hwd hws hwo hwr],'Standared Capon','Robust Capon (Batch)','Robust Capon (SS)','Robust (SOCP)','Proposed')

%array pattern plot
iter =0;
for dtheta=-90:1:90 
    thetar=dtheta*(pi/180);     % Angle in radians
    iter=iter+1;
    %calcuate steering vector at certain direction for interested signal;
        for j=1:M
           P(j,1)=exp((j-1)*i*2*pi*d*sin(thetar));
        end
        
        %p1(j)=exp((j-1)*i*2*pi*d*sin(theta));
        H1 = [A1*P(:,1), A2*P(:,2), A3*P(:,3)];%construct new system matrix
        
        gp(iter) = 10*log10(abs(SINRF(wp,H1,Ndb,1))); %calculate gain of standared Capon 
        gd(iter) = 10*log10(abs(SINRF(wd,H1,Ndb,1))); %calculate gain of conventional
        gs(iter) = 10*log10(abs(SINRF(ws,H1,Ndb,1))); %calculate gain of Robust Capon
        gr(iter) = 10*log10(abs(SINRF(wr,H1,Ndb,1))); %calculate gain of Robust Capon
        go(iter) = 10*log10(abs(SINRF(wo,H1,Ndb,1))); %calculate gain of Robust Capon
    end
    
gp =norm(gr)*(gp/norm(gp)); 
gd =norm(gr)*(gd/norm(gd));
gs =(norm(gr)*gs/norm(gs));
go =(norm(gr)*go/norm(go));
gr =gr;

f = [max(gp),max(gd),max(gs),max(gr),max(go)];
lim = max(f);
gpp = gp-lim; 
gdp = gd-lim;  
gsp = gs-lim;
grp = gr-lim;
gro = go-lim;

%plot battern in Horizental
figure(5);
h1 = plot([-90:1:90]*pi/180,gpp,'r');  
hold on;
h2 = plot([-90:1:90]*pi/180,gdp,'g'); 
hold on;
h3 = plot([-90:1:90]*pi/180,gsp,'b'); 
hold on;
h4 = plot([-90:1:90]*pi/180,gro,'m'); 
hold on;
h5 = plot([-90:1:90]*pi/180,grp,'k'); 


hold on;
q = axis;
plot(theta1,q(3):0.1:q(4));
hold on;
plot(theta2,q(3):0.1:q(4));
hold on;
plot(theta3,q(3):0.1:q(4));

legend([h1 h2 h3 h4 h5],'Standared Capon','Robust Capon (Batch)','Robust Capon (SS)','Robust (SOCP)','Proposed')




