% This script plot the SINR versus Noise 
clear all;
close all;
M = 5;                    % Elements in array
d = 1/2;                  % sensor spacing half wavelength wrt wc
N = 1000;                 % number of samples  
f1 = 0.01 ;               % frequancy of S1
f2 = 0.02 ;               % frequancy of S2
f3 = 0.03;                % frequancy of S2
A1 =10^(0/20);            % Amplitude of sinusoid (required)
A2 =10^(10/20);           % Amplitude of first sinterfernce (10 db stronger) 
A3 =10^(10/20);           % Amplitude of second sinterfernce (10 db stronger)  
L = 3;                    % number of sources
theta1 = 0;               % Direction of arrival of interested signal
theta2 = pi/4;            % Second direction of arrival for first interfernce
theta3 = pi/6;            % thired direction of arrival for second interfernce 
zeta = 1;                 % inverse matrix initialization
Ln = 1;                   % define the forgetting factor  
ff = 0.97;                % Forgetting factorof subspace traking algorithm
%EV = (10^(Ndb/20)/sqrt(2)/M)*eye(M); % inialaize eigenvalues matrix 
ep1 = 1;                  % tolerance value for the proposed
ep2 = 1;                  % tolerance value for the robust with eigendecomposition
ep3 = 2;                 % tolerance value for SOCP
G = 0;                    % initalize QI constraint gradient
alfa1 = 0.008;             % initalize the coffeiant of step-size 
VL = 1;                   % proposed Variable loading Technique 
misang = 0.06*pi;         % mismatch angle
%misang = 0;
diagl = 0;                % fixed diagonal loadingterm for SOCP
%define source signal
s1	= A1*cos(2*pi*f1*(1:N)) ;
s2	= A2*sign(cos(2*pi*f2*(1:N)));
%s3	= A3*(cos(2*pi*f3*(1:N))) ;
s3	= A3*sign(randn(1,N)) ;

S	= [ s1 ; s2 ; s3 ] ;                %source signal with dimention L*N rows of signal

%Intialize steering vectors
P=zeros(M,L);  

%generate steering vectors
for j=1:M
   P(j,1)=exp((j-1)*i*2*pi*d*sin(theta1));
end
for j=1:M
   P(j,2)=exp((j-1)*i*2*pi*d*sin(theta2));
end
for j=1:M
   P(j,3)=exp((j-1)*i*2*pi*d*sin(theta3));
end
Pa = P(:,1);  %save correct DOA
% generate recived signal vectors from antenna array 
%Conventional  Beamformer 
Pdata = P;
H = [A1*P(:,1), A2*P(:,2), A3*P(:,3)];

for j=1:M
   P(j,1)=exp((j-1)*i*2*pi*d*sin(theta1+misang));
end
itr =0;
for Ndb = 20:-2:-30
    itr = itr+1;
    En = orth(rand(M,M-L)+i*rand(M,M-L)); % inialaize eigenvector matrix with orthogonal matrix
    Es = orth(rand(M,L)+i*rand(M,L));     % inialaize eigenvector matrix with orthogonal matrix
    wp = zeros(M,1);          % initialize the conventional capon 
    IR = zeta*eye(M);         % initalize the inverse autocorrelation matrix
    Rs = (1/zeta)*eye(M);     % initalize the inverse autocorrelation matrix
    noiseamp = 10^(Ndb/20)/sqrt(2);      %noise amplitude for complex noise
    V=noiseamp*randn(M,N)+i*noiseamp*randn(M,N); %noise process generaation 
    X = Pdata*S+V ;%recived signal with dimention M*N
    as = (P(:,1)/norm(P(:,1)))*M;       %normalize the presumed steering vector for SOCP
    Pr = P(:,1);  %initialize the robust steering vector;
    Gr = IR*Pr;   %initialize the gradient; 
  for k = 1:N 
    r = X(:,k); %take one snapshot receiving vector
    Rs  = Ln*Rs + r*r';                     % autocorrelation matrix of recived signal  
    dem = real(1/(Ln+ r'*IR*r));            % 
    Kn = dem*IR*r;                          % Kalaman gain        
    IR = (1/Ln)*(IR - Kn*r'*IR);            % update inverse of Autocorrolation matrix 
    D = Gr+G;                               % update the previous gradient with Diagonal loading term
    mu = real((alfa1*D'*D)/(real(D'*IR*D)+0.000001)); % update the step size 
    Gr = IR'*Pr;                            % Calculate the gradient 
    pp1 = Pr-P(:,1);                        % it must satisfy the constraint 
    Pr1= Pr - mu*Gr;                        % update the robust steering vector w/t QI constraint  
    pp2 = Pr1-P(:,1);                       % calculate the difference with known steering vector
    if (norm(pp2)^2)> ep1                   % check for QC condition on pp vector;
        switch VL
            case 1
                cc = pp2'*pp2-ep1;                                    % positive
                bb = 2*mu*real(pp2'*pp1);                             % positive
                aa = (mu^2)*(pp1'*pp1);                               % positive
                landa = (bb-real(((bb^2)-(4*aa*cc))^0.5))/(2*aa);     % estimate diagonal Loading term
                Pr1 = Pr -mu*Gr-mu*landa*pp1;                         % apply Quadritic inquallity constrain
                G = landa*pp1;                                        % gradient of QC term to be added in advance  
            case 2
                Pr1 = P(:,1)+ ep1*((pp2)/norm(pp2));                  %scalled projection
            case 3
        end
    else
        G = 0;
    end
    Pr = Pr1;
    %performing robust of compared algorithm   
    %IRs = inv(Rs);
    [U,D] = eig(Rs);                                    % get eigen vectors and values of autocorrelation matrix
    gm = real(diag(D));                                 % get eigenvalues in one vector
    z = U'*P(:,1);                                      % get vecotr to estimate the diagonal loading term
    landa1 = newton1(z,gm,ep2,P(:,1));                  % get the diagonal loading term by newton method
    Pd = P(:,1) - (inv(eye(M)+landa1*Rs))*P(:,1);       % get equivalent steering vector with uncertainities
    
    Es = NOOjacom(r,Es,1,0.001,0.01);                  % Signal subspace tracking
    En = NOOjacom(r,En,-1,0.001,0.01);                  % noise subspace tracking 

    Es = flipdim(Es,2);
    E = [En Es];                                        % combine signal subspaces
    EV = real(diag(E'*Rs*E));               
    E1 = E'*P(:,1);                                     % get vecotr to estimate the diagonal loading term
    landa2 = newton1(E1,EV,ep2,P(:,1));                 % get the diagonal loading term by newton method
    Ps = P(:,1) - (inv(eye(M)+landa2*Rs))*P(:,1);       % get equivalent steering vector with uncertainities
    
    if mod(k-1,100)==0
    %SOCP using SeDuMi software package 
       wo = robustbeam(Rs,as,ep3,diagl);
    end
    %Power
    pwp(k) = 1/(real(P(:,1)'*IR*P(:,1)));               % output power of standared beamformer
    pwr(k) = 1/(real(Pr'*IR*Pr));                       % output power of robust beamformer
    pwd(k) = 1/(real(Pd'*IR*Pd));                       % 
    pws(k) = 1/(real(Ps'*IR*Ps));   
    pwo(k) = real(wo'*Rs*wo);                           % o/p power of SOCP
    
    %Beamformer
    wr = (IR*Pr)*pwr(k);                     % robust Capon beamforming
    wp = (IR*P(:,1))*pwp(k);                 % conventional capon beamformer 
    wd = (IR*Pd)*pwd(k);                     % robust2 capon beamforming
    ws = (IR*Ps)*pws(k);
    %SINR

end
    SINRPm(itr) = SINRF(wp,H,Ndb,1);             % SINR of standared capon beamformer 
    SINRRm(itr) = SINRF(wr,H,Ndb,1);             % SINR of robust capon beamformer 
    SINRDm(itr) = SINRF(wd,H,Ndb,1);
    SINRSm(itr) = SINRF(ws,H,Ndb,1);
    SINROm(itr) = SINRF(wo,H,Ndb,1);
end
%Smoothing
%Butter worht smoothing Filter
[filt_num,filt_den] = butter(1,10^(-1));
%SINR
SINRPm = 10*log10(abs(filtfilt(filt_num,filt_den,SINRPm)));
SINRRm = 10*log10(abs(filtfilt(filt_num,filt_den,SINRRm)));
SINRDm = 10*log10(abs(filtfilt(filt_num,filt_den,SINRDm)));
SINRSm = 10*log10(abs(filtfilt(filt_num,filt_den,SINRSm)));
SINROm = 10*log10(abs(filtfilt(filt_num,filt_den,SINROm)));

%Plot SINR
t =20:-2:-30;
figure(3);
hsp = plot(t,SINRPm,'r'); 
hold on;
hsd = plot(t,SINRDm,'g');
hold on;
hss = plot(t,SINRSm,'b');
hold on;
hsr = plot(t,SINRRm,'k');
hold on;
hso = plot(t,SINROm,'m');

xlabel('Noise power (dB)');
ylabel('Output SINR (dB)');
title(' Signal-to-Interference+Noise Ratio'); 
legend([hsp hsd hss hso hsr],'Standared Capon','Robust Capon (Batch)','Robust Capon (SS)','Robust (SOCP)','Proposed');




