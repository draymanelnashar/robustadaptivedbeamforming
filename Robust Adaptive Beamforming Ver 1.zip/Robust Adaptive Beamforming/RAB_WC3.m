clear all;
close all;
%start montcarlo simulation
for mc = 1:1
M = 5;                                      % Elements in array
d = 0.5;                                    % sensor spacing half wavelength wrt wc
N = 1000;                                   % number of samples  
Ndb	=0;                                     % kind of noise level in dB
f1 = 0.03 ;                                 % frequancy of S1
f2 = 0.02 ;                                 % frequancy of S2
f3 = 0.01;                                  % frequancy of S2
A1 =10^(5/20);                              % Amplitude of sinusoid (required)
A2 =10^(10/20);                             % Amplitude of first sinterfernce (10 db stronger) 
A3 =10^(10/20);                             % Amplitude of second sinterfernce (10 db stronger)  
L = 3;                                      % number of sources
VL = 1;
alfa = 0.2;
theta1 = 0;                                 % Direction of arrival of interested signal
theta2 = pi/6;                              % Second direction of arrival for first interfernce
theta3 = pi/3;                              % thired direction of arrival for second interfernce 
zeta = 1;                                   % inverse matrix initialization
Ln = 1;                                     % define the forgetting factor  
ff = 0.97;                                  % Forgetting factorof subspace traking algorithm
dl = 0;
ep1 = 1;                                  % tolerance value for the proposed
ep2 = 1;                                    % tolerance value for the robust with eigendecomposition
ep3 = 5;                                   % tolerance value for SOCP
ep4 = 1.6;                                    % tolerance value for new robust detector  
ep5 = 1.8;
G = 0;                                      % initalize QI constraint gradient
it = 0;                                     % This counter for number of VL subrouting excution
it1 = 0;
wp = zeros(M,1);                            % initialize the conventional capon 
IR = zeta*eye(M);                           % initalize the inverse autocorrelation matrix
Rs = (1/zeta)*eye(M);                       % initalize the inverse autocorrelation matrix
alfa1 = 0.008;                               % initalize the coffeiant of step-size                                    % proposed Variable loading Technique 
alfa3 =0.01;
misang = 0.03*pi;                           % mismatch angle
%misang = 0;
diagl = 0;                                  % fixed diagonal loadingterm for SOCP
QE = [];
%define source signal
s1	= A1*cos(2*pi*f1*(1:N)) ;
s2	= A2*sign(cos(2*pi*f2*(1:N)));
%s3	= A3*(cos(2*pi*f3*(1:N))) ;
s3	= A3*sign(randn(1,N)) ;

S	= [ s1 ; s2 ; s3 ] ;                %source signal with dimention L*N rows of signal
noiseamp = 10^(Ndb/20)/sqrt(2);      %noise amplitude for complex noise
V=noiseamp*randn(M,N)+i*noiseamp*randn(M,N); %noise process generaation 

%Intialize steering vectors
P=zeros(M,L);  

%generate steering vectors
for j=1:M
   P(j,1)=exp((j-1)*i*2*pi*d*sin(theta1));
end
for j=1:M
   P(j,2)=exp((j-1)*i*2*pi*d*sin(theta2));
end
for j=1:M
   P(j,3)=exp((j-1)*i*2*pi*d*sin(theta3));
end
Pa = P(:,1);  %save correct DOA
% generate recived signal vectors from antenna array 
X = P*S+V ;%recived signal with dimention M*N
H = [A1*P(:,1), A2*P(:,2), A3*P(:,3)];
%add mismatch error to steering vector by 
for j=1:M
   P(j,1)=exp((j-1)*i*2*pi*d*sin(theta1+misang));
end
 
as = (P(:,1)/norm(P(:,1)))*M; %normalize the presumed steering vector for SOCP
%P(:,1) = as;
%Conventional  Beamformer 
R_v = 10^(Ndb/10)*eye(M,M);        %noise matrix
IR_v= pinv(R_v);
pwc = 1/((P(:,1))'*IR_v*(P(:,1))); %output power 
Ko = P(:,1)'*IR_v*pwc;             %Optimal gain vector (Capon beamformer) 
itr1 = 0;
Tw1 = 1;
%adaptive beamforming start now (capon beamforming)
% initialaize the beamformer
wc = P(:,1)/M; % conventional beamformer;
%H = [A1*P(:,1), A2*P(:,2), A3*P(:,3)]; %generate mixing matrix which including the amplitudes
Pr = P(:,1);  %initialize the robust steering vector; 
%C =P(:,1); 
%Pr = zeros(M,1);
Gr = IR*Pr;   %initialize the gradient; 
%Pc1 = eye(M)-(C*C')/real((C'*C)); %Projection matrix for conventional capon beamforming
%Pc2 = eye(M)-(Pr*Pr')/real((Pr'*Pr)); 
for k = 1:N 
    r = X(:,k); %take one snapshot receiving vector
    Rs  = Ln*Rs + r*r';                     % autocorrelation matrix of recived signal  
    dem = real(1/(Ln+ r'*IR*r));            % 
    Kn = dem*IR*r;                          % Kalaman gain        
    IR = (1/Ln)*(IR - Kn*r'*IR);            % update inverse of Autocorrolation matrix 
    D = Gr+G;                               % update the previous gradient with Diagonal loading term
    mu = real((alfa1*D'*D)/(real(D'*IR*D)+0.00000001)); % update the step size 
    Gr = IR'*Pr;                            % Calculate the gradient 
    %mu = real((alfa1*Gr'*Gr)/(real(Gr'*IR*Gr)+0.00000001)); 
    pp1 = Pr-P(:,1);                        % it must satisfy the constraint 
    Pr1= Pr - mu*Gr;                        % update the robust steering vector w/t QI constraint  
    pp2 = Pr1-P(:,1);                       % calculate the difference with known steering vector
    if (norm(pp2)^2)> ep1                   % check for QC condition on pp vector1  
                cc = pp2'*pp2-ep1;                                    % positive
                bb = 2*mu*real(pp2'*pp1);                             % positive
                aa = (mu^2)*(pp1'*pp1);                               % positive
                landa = (bb-real(((bb^2)-(4*aa*cc))^0.5))/(2*aa);     % estimate diagonal Loading term
                Pr1 = Pr -mu*Gr-mu*landa*pp1;                         % apply Quadritic inquallity constrain
                G = landa*pp1;                                        % gradient of QC term to be added in advance  
                it = it+1;
            else
        G = 0;
    end
    %end
    Pr = Pr1; % steering vector of robust proposed technique
    %performing robust of compared algorithm   
    %IRs = inv(Rs);
    [U,D] = eig(Rs);                                    % get eigen vectors and values of autocorrelation matrix
    gm = real(diag(D));                                 % get eigenvalues in one vector
    z = U'*P(:,1);                                      % get vecotr to estimate the diagonal loading term
    landa1 = newton1(z,gm,ep2,P(:,1));                  % get the diagonal loading term by newton method
    Pd = P(:,1) - (inv(eye(M)+landa1*Rs))*P(:,1);       % get equivalent steering vector with uncertainities   
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % New robust detector similar to SOCP constraint and solved using
    % technique similar to the above one 
    Tw = newton2(z,gm,ep4,P(:,1),dl); % get norm of weight vector using newton like algorithm.
    if min(Tw)>0
    Tw1 = min(Tw);
    end
    ws = inv(Rs+(dl+(ep4/Tw1))*eye(M))*P(:,1); % weight vector of robust beamformer
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    as1 = P(:,1); %orginal steering vector 
    %as1 = Pr;
    if k==1
    wd = IR*as1;%/(real(as1'*IR*as1)); % initalize new robust detector.
    %wd = as1;
    end
    as2 = (as1- ep5*(wd/norm(wd))); %modified steering vector
    grd=Rs*wd;%-as2;
    mu2 = alfa3*(norm(grd))^2/(real(grd'*Rs*grd)+0.000000001);
    %mu2 = 0.00001;
    wd1 = wd-mu2*grd; %initial weight vector without robustness
    if real(wd1'*as1) < ep5*norm(wd1)+1 %check for robustness condition 
        A1 = mu2^2*((real(as2'*as1))^2-ep5^2*((norm(as2))^2));
        B1 = mu2*(real(wd1'*as1-1)*real(as2'*as1)-ep5^2*real(wd1'*as2));
        C1 = (real(wd1'*as1)-1)^2-ep5^2*norm(wd1)^2;
        landa3 = (-B1+((B1^2-A1*C1)^0.5))/A1; 
        wd = wd1+mu2*landa3*as2;
        itr1 = itr1 +1;
        QE = [QE; A1 B1 C1 landa3]; %QC parameters
    else
        wd = wd1;
        landa3 = 0;
        QE = [QE; 0 0 0 0];
    end
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   % SOCP Detector
    if mod(k-1,10)==0
    %as = (Pr/norm(Pr))*M;     
    %SOCP using SeDuMi software package 
       [wo] = robustbeam(Rs,as,ep3,diagl);
    end
    %Power estimation
    pwp(k,mc) = 1/(real(P(:,1)'*IR*P(:,1)));               % output power of standared beamformer
    pwd(k,mc) = real((wd'/norm(wd))*Rs*(wd/norm(wd)));                          
    pws(k,mc) = real((ws'/(norm(ws)))*Rs*(ws/(norm(ws))));                         
    pwo(k,mc) = real((wo'/(norm(wo)))*Rs*(wo/(norm(wo))));                           % o/p power of SOCP
    pwr(k,mc) = 1/(real(Pa'*IR*Pa));                       % output power of benchmark
    
    %Beamformer
    wr = (IR*Pa)*pwr(k,mc);                        % Benchmarck Capon beamforming
    wp = (IR*P(:,1))*pwp(k,mc);                 % conventional capon beamformer 
    
    pwp(k,mc) =  real((wp'/norm(wp))*Rs*(wp/norm(wp)));     
    pwr(k,mc) =   real((wr'/norm(wr))*Rs*(wr/norm(wr)));     
   
    %pwp(k,mc) =  real((wp')*Rs*(wp));     
    %pwr(k,mc) =   real((wr')*Rs*(wr));       
    
    % norm;
    norp(k,mc) = norm(wp);
    nord(k,mc) = norm(wd);
    nors(k,mc) = norm(ws);
    noro(k,mc) = norm(wo);
    norr(k,mc) = norm(wr);
    
      %Output
    op1(k,mc) = real(wp'*X(:,k));               % o/p signal of capon beamformin
    op2(k,mc) = real(wd'/(norm(wd))*X(:,k));               % o/p of robust2 beamforming
    op3(k,mc) = real(ws'*X(:,k));  
    op4(k,mc) = real(wo'*X(:,k)); 
    op5(k,mc) = real(wr'*X(:,k)); 
     %op2(k,mc) = real(wc'*X(:,k));               % o/p signal ofconventional beamforming            

    %MSE
    msep(k,mc) = (op1(k)-s1(k))^2;              % MSE of capon beamforming       
    msed(k,mc) = (op2(k)-s1(k))^2;              % MSE of robust2 capon beamforming
    mses(k,mc) = (op3(k)-s1(k))^2;
    mseo(k,mc) = (op4(k)-s1(k))^2;
    mser(k,mc) = (op5(k)-s1(k))^2;              % MSE of conventional beamforming   
    %SINR
    
    %wd = wd/norm(wd);
    
    SINRP(k,mc) = SINRF(wp,H,Ndb,1);             % SINR of standared capon beamformer          
    SINRD(k,mc) = SINRF(wd,H,Ndb,1);            
    SINRS(k,mc) = SINRF(ws,H,Ndb,1);
    SINRO(k,mc) = SINRF(wo,H,Ndb,1);
    SINRR(k,mc) = SINRF(wr,H,Ndb,1);            %benchmark MVDR beamforming 
   
end
end

%Smoothing and averaging over montcarlo simulation
%Butter worht smoothing Filter
[filt_num,filt_den] = butter(1,10^(-2));
%SINR
SINRP1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRP,2))));
SINRD1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRD,2))));
SINRS1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRS,2))));
SINRO1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRO,2))));
SINRR1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRR,2))));

%MSE
msep1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(msep,2))));
msed1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(msed,2))));
mses1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(mses,2))));
mseo1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(mseo,2))));
mser1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(mser,2))));

%Power
pwp1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(pwp,2))));
pwd1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(pwd,2))));
pws1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(pws,2))));
pwo1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(pwo,2))));
pwr1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(pwr,2))));

%Norm of weight vector
norp1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(norp,2))));
nord1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(nord,2))));
nors1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(nors,2))));
noro1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(noro,2))));
norr1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(norr,2))));

%Plot norm
figure(1);
hnp = plot(1:N, norp1,'k',1:100:N,norp1(1:100:N),'d');
hold on;
hnd = plot(1:N, nord1,'k',1:100:N,nord1(1:100:N),'*');
hold on;
hns = plot(1:N, nors1,'k',1:100:N,nors1(1:100:N),'^');
hold on;
hno = plot(1:N, noro1,'k',1:100:N,noro1(1:100:N),'o');
hold on;
hnr = plot(1:N, norr1,'k',1:100:N,norr1(1:100:N),'+');

legend([hnp(2) hno(2) hns(2) hnd(2) hnr(2)],'Standard MVDR','Robust MVDR-WC/SOCP','Robust MVDR-WC/EigDec','Robust MVDR-WC/Proposed','Benchmark MVDR');
xlabel('Snapshot');
ylabel('Norm (dB)');
title('Weight Vector Norm'); 

%Plot mse
figure(2);
hmp = plot(1:N, msep1,'k',1:100:N,msep1(1:100:N),'d');
hold on;
hmd = plot(1:N, msed1,'k',1:100:N,msed1(1:100:N),'*');
hold on;
hms = plot(1:N, mses1,'k',1:100:N,mses1(1:100:N),'^');
hold on;
hmo = plot(1:N, mseo1,'k',1:100:N,mseo1(1:100:N),'o');
hold on;
hmr = plot(1:N, mser1,'k',1:100:N,mser1(1:100:N),'+');

legend([hmp(2) hmo(2) hms(2) hmd(2) hmr(2)],'Standard MVDR','Robust MVDR-WC/SOCP','Robust MVDR-WC/EigDec','Robust MVDR-WC/Proposed','Benchmark MVDR');
xlabel('Snapshot');
ylabel('MSE (dB)');
title('Mean Squared Error'); 
%Plot SINR

figure(3);
hsp = plot(1:N, SINRP1,'k',1:100:N,SINRP1(1:100:N),'d'); 
hold on;
hsd = plot(1:N, SINRD1,'k',1:100:N,SINRD1(1:100:N),'*');
hold on;
hss = plot(1:N, SINRS1,'k',1:100:N,SINRS1(1:100:N),'^');
hold on;
hso = plot(1:N, SINRO1,'k',1:100:N,SINRO1(1:100:N),'o');
hold on;
hsr = plot(1:N, SINRR1,'k',1:100:N,SINRR1(1:100:N),'+');

xlabel('Snapshot');
ylabel('SINR (dB)');
title(' Signal-to-Interference+Noise Ratio'); 
legend([hsp(2) hso(2) hss(2) hsd(2) hsr(2)],'Standard MVDR','Robust MVDR-WC/SOCP','Robust MVDR-WC/EigDec','Robust MVDR-WC/Proposed','Benchmark MVDR');

%Plot power
figure(4);
hwp = plot(1:N, pwp1,'k',1:100:N,pwp1(1:100:N),'d');
hold on;
hwd = plot(1:N, pwd1,'k',1:100:N,pwd1(1:100:N),'*');
hold on;
hws = plot(1:N, pws1,'k',1:100:N,pws1(1:100:N),'^');
hold on;
hwo = plot(1:N, pwo1,'k',1:100:N,pwo1(1:100:N),'o');
hold on;
hwr = plot(1:N, pwr1,'k',1:100:N,pwr1(1:100:N),'+');

xlabel('Snapshot');
ylabel('SOI Power (dB)');
title(' Signal of Interest Power'); 
legend([hwp(2) hwo(2) hws(2) hwd(2) hwr(2)],'Standard MVDR','Robust MVDR-WC/SOCP','Robust MVDR-WC/EigDec','Robust MVDR-WC/Proposed','Benchmark MVDR');

%Plot mse
figure(5);
title('WC Constraint Parameters'); 
subplot(2,2,1)
hda = plot(10:N, QE(10:N,1),'b',10:100:N,QE(10:100:N,1),'*b');
xlabel('Snapshot');
title('A'); 
subplot(2,2,2)
hdb = plot(3:N, QE(3:N,2),'b',3:100:N,QE(3:100:N,2),'*b');
xlabel('Snapshot');
title('B'); 
subplot(2,2,3)
hdc = plot(3:N, QE(3:N,3),'b',3:100:N,QE(3:100:N,3),'*b');
xlabel('Snapshot');
title('C'); 
subplot(2,2,4)
hdl = plot(3:N, QE(3:N,4),'b',3:100:N,QE(3:100:N,4),'*b');
xlabel('Snapshot');
title('\lambda'); 

%array pattern plot
iter =0;
for dtheta=-90:1:90 
    thetar=dtheta*(pi/180);     % Angle in radians
    iter=iter+1;
    %calcuate steering vector at certain direction for interested signal;
        for j=1:M
           P(j,1)=exp((j-1)*i*2*pi*d*sin(thetar));
        end
        
        %p1(j)=exp((j-1)*i*2*pi*d*sin(theta));
        H1 = [A1*P(:,1), A2*P(:,2), A3*P(:,3)];%construct new system matrix
        gp(iter) = 10*log10(abs(SINRF(wp,H1,Ndb,1))); %calculate gain of standared Capon 
        gd(iter) = 10*log10(abs(SINRF(wd,H1,Ndb,1))); %calculate gain of conventional
        gs(iter) = 10*log10(abs(SINRF(ws,H1,Ndb,1))); %calculate gain of Robust Capon
        go(iter) = 10*log10(abs(SINRF(wo,H1,Ndb,1))); %calculate gain of Robust Capon
        gr(iter) = 10*log10(abs(SINRF(wr,H1,Ndb,1))); %calculate gain of Robust Capon
end
  
mno = max([norm(gp),norm(gd),norm(gs),norm(go), norm(gr)]);    

gp =mno*(gp/norm(gp)); 
gd =mno*(gd/norm(gd));
gs =mno*(gs/norm(gs));
go =mno*(go/norm(go));
gr =mno*(gr/norm(gr));

f = [max(gp),max(gd),max(gs),max(go), max(gr)];
lim = max(f);
gpp = gp-lim; 
gdp = gd-lim;  
gsp = gs-lim;
gop = go-lim;
grp = gr-lim;

%plot battern in Horizental
figure(6);
h1 = plot([-90:1:90]*pi/180,gpp,'r');  
hold on;
h2 = plot([-90:1:90]*pi/180,gdp,'k'); 
hold on;
h3 = plot([-90:1:90]*pi/180,gsp,'b'); 
hold on;
h4 = plot([-90:1:90]*pi/180,gop,'m'); 
hold on;
h5 = plot([-90:1:90]*pi/180,grp,'g'); 

hold on;
q = axis;
plot(theta1,q(3):1:q(4),'-');
hold on;
plot(theta2,q(3):1:q(4),'-');
hold on;
plot(theta3,q(3):1:q(4),'-');

legend([h1 h4 h3 h2 h5],'Standard MV Beamformer','Robust MV-WC/SOCP','Robust MV-WC/EigDec','Robust MV-WC/Proposed','Benchmark MVDR')


