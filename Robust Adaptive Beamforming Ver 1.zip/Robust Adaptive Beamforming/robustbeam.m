% wrob = robustbeam(Rss,as,delt,diagl)
%
% INPUT ARGUMENTS
% 'Rss'   is sample covariance matrix
% 'as'    is steering vector   (it should be normalized that ||as||^2 = n, 
%         where n is number of sensors in array) 
% 'delt'  is boundary for error mismatch vector, i.e. as_real = as_nominal + as_mismatch
%         ||a_mismatch||<=delt; 'delt' should be choosen in range [0,0.3*n] 
% 'diagl' is diagonal loading coefficient (put 'diagl=0' for no diagonal loading)
%
% OUTPUT ARGUMENT
% 'wrob' is vector of beamformer weights
%
% Robust Adaptive Beamforming Using Second-Order Cone Programming
% copyright Sergiy A. Vorobyov, Alex B. Gershman; May 22, 2001
% email: svor@mail.ece.mcmaster.ca

function [wrob] = robustbeam(Rss,as,delt,diagl)
[n,n] = size(Rss);      % number of sensors in array
Rss = Rss + eye(n,n)*diagl; % diagonal loading 
Rss=(Rss-diag(diag(Rss)))+diag(real(diag(Rss)));
L=chol(real(Rss));         % Cholesky factorization of sample cov. matrix 'Rss'
L_tilde=[real(L),-imag(L);imag(L),real(L)];  % 'L_tilde' defined based on 'L'
as_tilde=[real(as);imag(as)];  % 'as_tilde' difined based on 'as'

[A,b,c,K]=dsfrb(L_tilde,as_tilde,delt);   % Create dual standard form for 
                                          % robust beamforming
[x,y]=sedumi(A,b,c,K);     % solution of optimization problem
%[obj,x,y,z] = sqlp(A,b,c,K); 

wrob=x(2:n+1)+1i*x(n+2:2*n+1);     % vector of parameters of robust beamformer 