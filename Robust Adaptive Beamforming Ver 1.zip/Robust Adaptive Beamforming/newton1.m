function landa1 = newton1(z,gm,ep,a);
i = 2;
land(i-1) = 0;
land(i) = (norm(a)-sqrt(ep))/(max(gm)*sqrt(ep)); %statrt value for landa

while land(i)-land(i-1) > 0.000001 %check for tolerance factor
    i=i+1;
    land(i) = land(i-1)+ 0.5*(sum((abs(z).^2)./((1+land(i-1)*gm).^2))-ep)...
        /(sum(((abs(z).^2).*gm)./((1+land(i-1)*gm).^3)));  %update diagonal loading term using newton equation
end

landa1 = land(i); 


