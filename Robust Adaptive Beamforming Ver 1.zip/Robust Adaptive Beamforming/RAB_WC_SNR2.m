clear all;
close all;
M = 5;                                      % Elements in array
d = 0.5;                                    % sensor spacing half wavelength wrt wc
N = 100;                                    % number of samples  
f1 = 0.03 ;                                 % frequancy of S1
f2 = 0.02 ;                                 % frequancy of S2
f3 = 0.01;                                  % frequancy of S2
A1 =10^(5/20);                              % Amplitude of sinusoid (required)
A2 =10^(10/20);                             % Amplitude of first sinterfernce (10 db stronger) 
A3 =10^(10/20);                             % Amplitude of second sinterfernce (10 db stronger)  
L = 3;                                      % number of sources
VL = 1;
alfa = 0.2;
theta1 = 0;                                 % Direction of arrival of interested signal
theta2 = pi/6;                              % Second direction of arrival for first interfernce
theta3 = pi/3;                              % thired direction of arrival for second interfernce 
zeta = 1;                                   % inverse matrix initialization
Ln = 1;                                     % define the forgetting factor  
ff = 0.97;                                  % Forgetting factorof subspace traking algorithm
dl = 0;
ep1 = 1;                                    % tolerance value for the proposed
ep2 = 1;                                    % tolerance value for the robust with eigendecomposition
ep3 = 3;                                    % tolerance value for SOCP
ep4 = 1.8;                                    % tolerance value for new robust detector  
ep5 = 1.8;
it = 0;                                     % This counter for number of VL subrouting excution
it1 = 0;
alfa1 = 0.008;                               % initalize the coffeiant of step-size                                    % proposed Variable loading Technique 
alfa3 =0.01;
misang = 0.02*pi;                           % mismatch angle
%misang = 0;
diagl = 0;                                  % fixed diagonal loadingterm for SOCP
QE = [];
%define source signal
s1	= A1*cos(2*pi*f1*(1:N)) ;
s2	= A2*sign(cos(2*pi*f2*(1:N)));
%s3	= A3*(cos(2*pi*f3*(1:N))) ;
s3	= A3*sign(randn(1,N)) ;

S	= [ s1 ; s2 ; s3 ] ;                %source signal with dimention L*N rows of signal
%Intialize steering vectors
P=zeros(M,L);  
[filt_num,filt_den] = butter(1,10^(-1));
%generate steering vectors
for j=1:M
   P(j,1)=exp((j-1)*i*2*pi*d*sin(theta1));
end
for j=1:M
   P(j,2)=exp((j-1)*i*2*pi*d*sin(theta2));
end
for j=1:M
   P(j,3)=exp((j-1)*i*2*pi*d*sin(theta3));
end
Pa = P(:,1);  %save correct DOA
% generate recived signal vectors from antenna array 
%X = P*S+V ;%recived signal with dimention M*N
Pdata = P;
H = [A1*P(:,1), A2*P(:,2), A3*P(:,3)];
%add mismatch error to steering vector by 
for j=1:M
   P(j,1)=exp((j-1)*i*2*pi*d*sin(theta1+misang));
end
itr =0; 
for Ndb = 20:-2:-30
    itr = itr+1;
    as = (P(:,1)/norm(P(:,1)))*M; %normalize the presumed steering vector for SOCP
    R_v = 10^(Ndb/10)*eye(M,M);        %noise matrix
    IR_v= pinv(R_v);
    pwc = 1/((P(:,1))'*IR_v*(P(:,1))); %output power 
    Ko = P(:,1)'*IR_v*pwc;             %Optimal gain vector (Capon beamformer) 
    itr1 = 0;
    Tw1 = 1;
    En = orth(rand(M,M-L)+i*rand(M,M-L)); % inialaize eigenvector matrix with orthogonal matrix
    Es = orth(rand(M,L)+i*rand(M,L));     % inialaize eigenvector matrix with orthogonal matrix
    wp = zeros(M,1);          % initialize the conventional capon 
    wc = P(:,1)/M; % conventional beamformer;
    IR = zeta*eye(M);         % initalize the inverse autocorrelation matrix
    Rs = (1/zeta)*eye(M);     % initalize the inverse autocorrelation matrix
    noiseamp = 10^(Ndb/20)/sqrt(2);      %noise amplitude for complex noise
    V=noiseamp*randn(M,N)+i*noiseamp*randn(M,N); %noise process generaation 
    X = Pdata*S+V ;%recived signal with dimention M*N
    as = (P(:,1)/norm(P(:,1)))*M;       %normalize the presumed steering vector for SOCP
    Pr = P(:,1);  %initialize the robust steering vector;
    Gr = IR*Pr;   %initialize the gradient; 
    G = 0;                                      % initalize QI constraint gradient
for k = 1:N 
    r = X(:,k); %take one snapshot receiving vector
    Rs  = Ln*Rs + r*r';                     % autocorrelation matrix of recived signal  
    dem = real(1/(Ln+ r'*IR*r));            % 
    Kn = dem*IR*r;                          % Kalaman gain        
    IR = (1/Ln)*(IR - Kn*r'*IR);            % update inverse of Autocorrolation matrix 
    D = Gr+G;                               % update the previous gradient with Diagonal loading term
    mu = real((alfa1*D'*D)/(real(D'*IR*D)+0.00000001)); % update the step size 
    Gr = IR'*Pr;                            % Calculate the gradient 
    %mu = real((alfa1*Gr'*Gr)/(real(Gr'*IR*Gr)+0.00000001)); 
    pp1 = Pr-P(:,1);                        % it must satisfy the constraint 
    Pr1= Pr - mu*Gr;                        % update the robust steering vector w/t QI constraint  
    pp2 = Pr1-P(:,1);                       % calculate the difference with known steering vector
    if (norm(pp2)^2)> ep1                   % check for QC condition on pp vector1  
                cc = pp2'*pp2-ep1;                                    % positive
                bb = 2*mu*real(pp2'*pp1);                             % positive
                aa = (mu^2)*(pp1'*pp1);                               % positive
                landa = (bb-real(((bb^2)-(4*aa*cc))^0.5))/(2*aa);     % estimate diagonal Loading term
                Pr1 = Pr -mu*Gr-mu*landa*pp1;                         % apply Quadritic inquallity constrain
                G = landa*pp1;                                        % gradient of QC term to be added in advance  
                it = it+1;
            else
        G = 0;
    end
    %end
    Pr = Pr1; % steering vector of robust proposed technique
    %performing robust of compared algorithm   
    %IRs = inv(Rs);
    [U,D] = eig(Rs);                                    % get eigen vectors and values of autocorrelation matrix
    gm = real(diag(D));                                 % get eigenvalues in one vector
    z = U'*P(:,1);                                      % get vecotr to estimate the diagonal loading term
    landa1 = newton1(z,gm,ep2,P(:,1));                  % get the diagonal loading term by newton method
    Pd = P(:,1) - (inv(eye(M)+landa1*Rs))*P(:,1);       % get equivalent steering vector with uncertainities   
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % New robust detector similar to SOCP constraint and solved using
    % technique similar to the above one 
    Tw = newton2(z,gm,ep4,P(:,1),dl); % get norm of weight vector using newton like algorithm.
    if min(Tw)>0
    Tw1 = min(Tw);
    end
    ws = inv(Rs+(dl+(ep4/Tw1))*eye(M))*P(:,1); % weight vector of robust beamformer
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    as1 = P(:,1); %orginal steering vector 
    %as1 = Pr;
    if k==1
    wd = IR*as1;%/(real(as1'*IR*as1)); % initalize new robust detector.
    end
    as2 = (as1- ep5*(wd/norm(wd))); %modified steering vector
    grd=Rs*wd;%-as2;
    mu2 = alfa3*(norm(grd))^2/(real(grd'*Rs*grd)+0.000000001);
    %mu2 = 0.0001;
    wd1 = wd-mu2*grd; %initial weight vector without robustness
    if real(wd1'*as1) < ep5*norm(wd1)+1 %check for robustness condition 
        A1 = mu2^2*((real(as2'*as1))^2-ep5^2*((norm(as2))^2));
        B1 = mu2*(real(wd1'*as1-1)*real(as2'*as1)-ep5^2*real(wd1'*as2));
        C1 = (real(wd1'*as1)-1)^2-ep5^2*norm(wd1)^2;
        landa3 = (-B1+(B1^2-A1*C1)^0.5)/A1; 
        wd = wd1+mu2*landa3*as2;
        itr1 = itr1 +1;
        QE = [QE; A1 B1 C1 landa3 norm(wd)];
    else
        wd = wd1;
        landa3 = 0;
    end
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   % SOCP Detector
    if mod(k-1,10)==0
    %as = (Pr/norm(Pr))*M;     
    %SOCP using SeDuMi software package 
       [wo] = robustbeam(Rs,as,ep3,diagl);
    end
    %Power estimation
    pwp(k) = 1/(real(P(:,1)'*IR*P(:,1)));               % output power of standared beamformer
    pwr(k) = 1/(real(Pa'*IR*Pa));                       % output power of robust beamformer
    pwd(k) = real(wd'*Rs*wd);                           % Ellipsoidal constraint beamforming 
    pws(k) = real((ws')*Rs*(ws));                         
    pwo(k) = real((wo')*Rs*(wo));                           % o/p power of SOCP
    
    %Beamformer
    wr = (IR*Pa)*pwr(k);                     % Benchmarck Capon beamforming
    wp = (IR*P(:,1))*pwp(k);                 % conventional capon beamformer 
    
    %wd = wd/norm(wd);
    SINRP(k) = SINRF(wp,H,Ndb,1);             % SINR of standared capon beamformer          
    SINRD(k) = SINRF(wd,H,Ndb,1);
    SINRS(k) = SINRF(ws,H,Ndb,1);
    SINRO(k) = SINRF(wo,H,Ndb,1);
    SINRR(k) = SINRF(wr,H,Ndb,1);
    

end

    %SINR
    SINRP1(itr) = mean(10*log10(abs(SINRP)));             % SINR of standared capon beamformer          
    SINRD1(itr) = mean(10*log10(abs(SINRD)));
    SINRS1(itr) = mean(10*log10(abs(SINRS)));
    SINRO1(itr) = mean(10*log10(abs(SINRO)));
    SINRR1(itr) = mean(10*log10(abs(SINRR)));
end

    SINRP2 = filtfilt(filt_num,filt_den,SINRP1);
    SINRD2 = filtfilt(filt_num,filt_den,SINRD1);
    SINRS2 = filtfilt(filt_num,filt_den,SINRS1);
    SINRO2 = filtfilt(filt_num,filt_den,SINRO1);
    SINRR2 = filtfilt(filt_num,filt_den,SINRR1);

    %Smoothing and averaging over montcarlo simulation
%Butter worht smoothing Filter

%SINRP2 = filtfilt(filt_num,filt_den,SINRP2);
%SINRD2 = filtfilt(filt_num,filt_den,SINRD2);
%SINRS2 = filtfilt(filt_num,filt_den,SINRS2);
%SINRO2 = filtfilt(filt_num,filt_den,SINRO2);
%SINRR2 = filtfilt(filt_num,filt_den,SINRR2);
    
%SINR
%SINRP1 = 10*log10(abs(filtfilt(filt_num,filt_den,SINRP)));
%SINRD1 = 10*log10(abs(filtfilt(filt_num,filt_den,SINRD)));
%SINRS1 = 10*log10(abs(filtfilt(filt_num,filt_den,SINRS)));
%SINRO1 = 10*log10(abs(filtfilt(filt_num,filt_den,SINRO)));
%SINRR1 = 10*log10(abs(filtfilt(filt_num,filt_den,SINRR)));
%Plot SINR

t =20:-2:-30;
figure(1);
hsp = plot(t, SINRP2,'-d'); 
hold on;
hsd = plot(t, SINRD2,'-*');
hold on;
hss = plot(t, SINRS2,'-^');
hold on;
hso = plot(t, SINRO2,'-o');
hold on;
hsr = plot(t, SINRR2,'-+');

xlabel('Noise power (dB)');
ylabel('SINR (dB)');
title(' Signal-to-Interference+Noise Ratio'); 
legend([hsp hso hss hsd hsr],'Standard MVDR','Robust MVDR-WC/SOCP','Robust MVDR-WC/EigDec','Robust MVDR-WC/Proposed','Benchmark MVDR');




