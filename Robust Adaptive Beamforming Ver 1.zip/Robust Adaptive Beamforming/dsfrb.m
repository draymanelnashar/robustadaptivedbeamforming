% [A,b,c,K]=dsfrb(L_tilde,as_tilde,delt)
% Create dual standard form for robust beamforming
% copyright Sergiy A.Vorobyov, Alex B.Gershman; May 15, 2001
% email: svor@mail.ece.mcmaster.ca

function [A,b,c,K]=dsfrb(L_tilde,as_tilde,delt)

[nn,nn]=size(L_tilde);
c=[zeros(nn+1,1);1;zeros(2*nn+1,1)];
A=[zeros(nn,1),-L_tilde,zeros(nn,1),eye(nn),zeros(nn,1),zeros(nn);...
   zeros(nn,1),delt*eye(nn),zeros(nn,1),zeros(nn,nn),zeros(nn,1),-eye(nn);...
   0,-as_tilde',zeros(1,nn+1),1,zeros(1,nn)]';
b=[zeros(2*nn,1);-1];
K.q=[nn+1,nn+1,nn+1];
K.ycomplex=1:length(b); 