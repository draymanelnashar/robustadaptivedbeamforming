function [w,z] = OPAST(r1,w,z,mu)
   %mu =0.995;
   y = w'*r1;  %vector of o/p
   q=z*y*(1/mu); %vector 
   gm = real(1/(1+y'*q)); %value
   z = (1/mu)*z -gm*(q*q'); %matrix update with eigenvalues on diagonal
   p1=gm*(r1-w*y); %vector
   fay= 1/sqrt(1+(norm(p1)^2)*(norm(q)^2)); %value
   T  = (fay-1)/norm(q)^2; %value
   p2 = T*w*q +(1+T*(norm(q)^2))*p1; %vector
   w = w+p2*q'; %update eigenvectors
   