clear all;
close all;
%start montcarlo simulation
for mc = 1:1
M = 5;                                      % Elements in array
d = 1/2;                                    % sensor spacing half wavelength wrt wc
N = 1000;                                   % number of samples  
Ndb	= 0;                                    % kind of noise level in dB
f1 = 0.03 ;                                 % frequancy of S1
f2 = 0.02 ;                                 % frequancy of S2
f3 = 0.01;                                  % frequancy of S2
A1 =10^(5/20);                              % Amplitude of sinusoid (required)
A2 =10^(10/20);                             % Amplitude of first sinterfernce (10 db stronger) 
A3 =10^(10/20);                             % Amplitude of second sinterfernce (10 db stronger)  
L = 3;                                            % number of sources
ml = 3;                                            %number of multipathes 
VL = 1;
alfa = 0.1;
theta1 = 0;                                 % Direction of arrival of interested signal
theta2 = pi/6;                              % Second direction of arrival for first interfernce
theta3 = pi/3;                              % thired direction of arrival for second interfernce 
zeta = 1;                                   % inverse matrix initialization
Ln = 1;                                     % define the forgetting factor  
ff = 0.97;                                  % Forgetting factorof subspace traking algorithm
dl = 0;
ep1 = 2;                                    % tolerance value for the ellipsoidal
ep2 = 2;                                    % tolerance eigendecoposition 
ep3 = 3;                                    % tolerance value for SOCP
ep4 = 1.6;                                    % tolerance value for eigendecoposition
ep5 = 1.6;                                  % tolerance for the proposed algorithm 
ep6 = [1.6 0.2 0.2];                           %equal gain combining constrained vector
L0 = [0.1;0.1;0.1];
II = [1.2 .5 .5];        
g1 =[1; 0.1 ; 0.1];
G = 0;                                      % initalize QI constraint gradient
it = 0;                                     % This counter for number of VL subrouting excution
it1 = 0;
wp = zeros(M,1);                            % initialize the conventional capon 
IR = zeta*eye(M);                           % initalize the inverse autocorrelation matrix
Rs = (1/zeta)*eye(M);                       % initalize the inverse autocorrelation matrix
alfa1 = 0.008;                               % initalize the coffeiant of step-size                                    % proposed Variable loading Technique 
alfa3 =0.1;                                 % step size factor of proposed algorithm 
alfa4 = 0.6;
misang = 0.03*pi;                           % mismatch angle
misang1 = 0.02*pi;
misang1 = 0;

diagl = 0;                                  % fixed diagonal loadingterm for SOCP
QE = [];
%define source signal
s1	= A1*cos(2*pi*f1*(1:N)) ;
s2	= A2*sign(cos(2*pi*f2*(1:N)));
%s3	= A3*(cos(2*pi*f3*(1:N))) ;
s3	= A3*sign(randn(1,N)) ;

Stot = [ s1 ; s2 ; s3 ] ;    

S	= [ s1 ; 0.4.*s1; 0.4.*s1 ;s2 ; s3 ] ;                %source signal with dimention L*N rows of signal
noiseamp = 10^(Ndb/20)/sqrt(2);      %noise amplitude for complex noise
V=noiseamp*randn(M,N)+i*noiseamp*randn(M,N); %noise process generaation 

%Intialize steering vectors
P=zeros(M,L);  
DOA(1) = theta1 - 30*pi/180; %generat  DOAs of multipathes componenet 
DOA(2) = theta1 - 80*pi/180;

%generate actual steering vectors 


for j=1:M
   P(j,1) = exp((j-1)*i*2*pi*d*sin(theta1)); %main path
   Ptot(j,1) =  P(j,1);
   for f=1:2 
       %phi(f) = 2*pi*rand(1); %generate phase of multipathes paths. 
       P1(j,f) =exp((j-1)*i*2*pi*d*sin(DOA(f)));
       Ptot(j,1) = Ptot(j,1)+ 0.4*P1(j,f); 
   end;
end

 RP = [P(:,1) P1(:,1:f)]; %generalized steering vector matrix with m*ml dimension


for j=1:M
   P(j,2)=exp((j-1)*i*2*pi*d*sin(theta2));
end
for j=1:M
   P(j,3)=exp((j-1)*i*2*pi*d*sin(theta3));
end

Pa = P(:,1);  %save correct DOA
% generate recived signal vectors from antenna array 
Ptot(:,2:3)=[P(:,2) P(:,3)] ;
X = Ptot*Stot+V ;%recived signal with dimention M*N withou

A = [RP P(:,2) P(:,3)]; %

%X1 = A*S + V;
H = [A1*P(:,1), A2*P(:,2), A3*P(:,3)];

H1 =  [A1*A(:,1), 0.4*A1*A(:,2), 0.4*A1*A(:,3), A2*A(:,4), A3*A(:,5)];

%generate Ptot with mismatch angles. 
for j=1:M
   P(j,1)=exp((j-1)*i*2*pi*d*sin(theta1+misang));
      Ptot(j,1) =  P(j,1);
      for f=1:2 
       %phi(f) = 2*pi*rand(1); %generate phase of multipathes paths. 
       P1(j,f) =exp((j-1)*i*2*pi*d*sin(DOA(f)+misang1));
       Ptot(j,1) = Ptot(j,1)+ 0.4*P1(j,f); 
   end
end

PL = [P(:,1) P1(:,1:f)]; %generalized steering vector matrix with m*ml dimension with mismatch
 
as = (P(:,1)/norm(P(:,1)))*M; %normalize the presumed steering vector for SOCP
%P(:,1) = as;
%Conventional  Beamformer 
R_v = 10^(Ndb/10)*eye(M,M);        %noise matrix
IR_v= inv(R_v);
pwc = 1/((P(:,1))'*IR_v*(P(:,1))); %output power 
Ko = P(:,1)'*IR_v*pwc;             %Optimal gain vector (Capon beamformer) 
itr1 = 0;
Tw1 = 1;
%adaptive beamforming start now (capon beamforming)
% initialaize the beamformer
wc = P(:,1)/M; % conventional beamformer;
%H = [A1*P(:,1), A2*P(:,2), A3*P(:,3)]; %generate mixing matrix which including the amplitudes
Pr = P(:,1);  %initialize the robust steering vector; 
%C =P(:,1); 
%Pr = zeros(M,1);
Gr = IR*Pr;   %initialize the gradient; 
%Pc1 = eye(M)-(C*C')/real((C'*C)); %Projection matrix for conventional capon beamforming
%Pc2 = eye(M)-(Pr*Pr')/real((Pr'*Pr)); 
for k = 1:N 
    r = X(:,k); %take one snapshot receiving vector
    Rs  = Ln*Rs + r*r';                     % autocorrelation matrix of recived signal  
    dem = real(1/(Ln+ r'*IR*r));            % 
    Kn = dem*IR*r;                          % Kalaman gain        
    IR = (1/Ln)*(IR - Kn*r'*IR);            % update inverse of Autocorrolation matrix 
   
    %IRs = inv(Rs);
    [U,D] = eig(Rs);                                    % get eigen vectors and values of autocorrelation matrix
    gm = real(diag(D));                                 % get eigenvalues in one vector
    z = U'*P(:,1);                                      % get vecotr to estimate the diagonal loading term
    landa1 = newton1(z,gm,ep2,P(:,1));                  % get the diagonal loading term by newton method
    Pd = P(:,1) - (inv(eye(M)+landa1*Rs))*P(:,1);       % get equivalent steering vector with uncertainities   
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % New robust detector similar to SOCP constraint and solved using
    % technique similar to the above one 
    Tw = newton2(z,gm,ep4,P(:,1),dl); % get norm of weight vector using newton like algorithm.
    if min(Tw)>0
    Tw1 = min(Tw);
    end
    ws = inv(Rs+(dl+(ep4/Tw1))*eye(M))*P(:,1); %weight vector of robust beamformer
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    as1 = P(:,1); %orginal steering vector 
    %as1 = Pr;
    if k==1
    wd = IR*as1;%/(real(as1'*IR*as1)); % initalize new robust detector.
    wd2 = IR*as1;
    end
    as2 = (as1- ep5*(wd/norm(wd))); %modified steering vector
    
    grd=Rs*wd;%-as2;
    grd1 = Rs*wd2;
    
    mu2 = alfa3*(norm(grd))^2/(real(grd'*Rs*grd)+0.000000001);
    mu3 = alfa4*(norm(grd1))^2/(real(grd1'*Rs*grd1)+0.000000001);
    %mu2 = 0.0001;
    wd1 = wd-mu2*grd; %initial weight vector without robustness
    
    wd11 = wd2-mu3*grd1;
    
    if real(wd1'*as1) < ep5*norm(wd1)+1 %check for robustness condition 
        A1 = mu2^2*((real(as2'*as1))^2-ep5^2*((norm(as2))^2));
        B1 = mu2*(real(wd1'*as1-1)*real(as2'*as1)-ep5^2*real(wd1'*as2));
        C1 = (real(wd1'*as1)-1)^2-ep5^2*norm(wd1)^2;
        landa3 = (-B1+(B1^2-A1*C1)^0.5)/A1; 
        wd = wd1+mu2*landa3*as2;
        itr1 = itr1 +1;
        QE = [QE; A1 B1 C1 landa3 norm(wd)];
    else
        wd = wd1;
        landa3 = 0;
    end
   
     chn = PL'*IR*PL;
  
    PL1 = PL-((wd11*ep6)/norm(wd11));  % get modified steering vector matrices 
  %  L0 = real(pinv(chn)*ep6');
  %if k==1  
  L0 = real(diag(pinv(chn)));
  %else
  %L0 = landa6;
  %end
     if any(real(wd11'*PL) < ep6*norm(wd11)+II)
         %options = optimset('tolfun', 1e-12);
    landa6= fsolve(@(L)wcg (PL,PL1,wd11,mu3,ep6,L,II'), L0);
    wd2 = wd11+mu3*PL1*landa6;    
     else
    wd2 = wd11;
    landa6 = 0;
     end    
         
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   % SOCP Detector
    if mod(k-1,10)==0
    %as = (Pr/norm(Pr))*M;     
    %SOCP using SeDuMi software package 
       [wo] = robustbeam(Rs,as,ep3,diagl);
    end
  
    
    % chn = pinv(real (PL'*IR*PL)); %cost function
    %[Q1,e1] = eig(chn);
    %e1 = diag(e1);
    %q1 = Q1(:,find(e1==max(e1))); 
    
     Pt = (RP(:,1)+0.4*RP(:,2)+ 0.4*RP(:,3));   %real steering vector
    
    %wr = (IR*RP)*pinv(real(RP'*IR*RP))*g1;                     % Benchmarck Capon beamforming
    wr = (IR*RP)*pinv(real(RP'*IR*RP))*g1;
    wp = (IR*PL)*pinv(real(PL'*IR*PL))*g1;                     % conventional capon beamformer with multiple constraint
    %wg = (IR*P(:,1))/(real(P(:,1)'*IR*P(:,1)));   %conventional Capon with single constraint 
    wg = (IR*Pa)/(real(Pa'*IR*Pa));   %conventional Capon with single constraint   
    
    % norm;
    norg(k,mc) = norm(wg); 
    norp(k,mc) = norm(wp);
    nord(k,mc) = norm(wd);
    nors(k,mc) = norm(ws);
    noro(k,mc) = norm(wo);
    norr(k,mc) = norm(wr);
    nord2(k,mc) = norm(wd2);
    
    %Power estimation
    pwg(k,mc) = real(wg'*Rs*wg);     
    pwp(k,mc) = real(wp'*Rs*wp);               % output power of Gen. standared beamformer
    pwd(k,mc) = real(wd'*Rs*wd);                           % Ellipsoidal constraint beamforming 
    pws(k,mc) = real((ws')*Rs*(ws));                         
    pwo(k,mc) = real((wo')*Rs*(wo));                           % o/p power of SOCP
    pwr(k,mc) =  real(wr'*Rs*wr);                      % output power of robust beamformer
    pwd2(k,mc) = real(wd2'*Rs*wd2);     
    %Beamformer

    %wd = wd/norm(wd);
    %SINR
    SINRG(k,mc) = SINRF(wg,H,Ndb,1);             % SINR of standared capon beamformer with single constraint          
    SINRP(k,mc) = SINRFm(wp,H1,Ndb);             % SINR of standared capon beamformer   with multiple constrint        
    SINRD(k,mc) = SINRFm(wd,H1,Ndb);
    SINRS(k,mc) = SINRF(ws,H,Ndb,1);
    SINRO(k,mc) = SINRF(wo/norm(wo),H,Ndb,1);
    SINRR(k,mc) = SINRFm(wr,H1,Ndb);
    SINRD2(k,mc) = SINRFm(wd2,H1,Ndb);
    
    %Output
    inorm = norm (X(:,k)); %calculate norm of input signal 
    op1(k,mc) = real(wg'*X(:,k))/(norm(wg)*inorm); %normalized output signal of the array              
    op2(k,mc) = real(wp'*X(:,k))/(norm(wp)*inorm);              % o/p signal of capon beamforming        
    op3(k,mc) = real(wd'*X(:,k))/(norm(wd)*inorm);             % o/p of robust2 beamforming
    op4(k,mc) = real(ws'*X(:,k))/(norm(ws)*inorm); 
    op5(k,mc) = real(wo'*X(:,k))/(norm(wo)*inorm); 
    op6(k,mc) = real(wr'*X(:,k))/(norm(wr)*inorm);               % o/p signal of conventional beamforming    
    op7(k,mc) = real(wd2'*X(:,k))/(norm(wd2)*inorm);               % o/p signal of conventional beamforming   
    
    %MSE
    mseg(k,mc) = (op1(k)-s1(k))^2;              % MSE of capon beamforming
    msep(k,mc) = (op2(k)-s1(k))^2;              % MSE of capon beamforming
    msed(k,mc) = (op3(k)-s1(k))^2;              % MSE of robust2 capon beamforming
    mses(k,mc) = (op4(k)-s1(k))^2;
    mseo(k,mc) = (op5(k)-s1(k))^2;
    mser(k,mc) = (op6(k)-s1(k))^2;              % MSE of conventional beamforming         
    msed2(k,mc) = (op7(k)-s1(k))^2;
end
end

%Smoothing and averaging over montcarlo simulation
%Butter worht smoothing Filter
[filt_num,filt_den] = butter(1,10^(-2));
%SINR
SINRG1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRG,2))));
SINRP1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRP,2))));
SINRD1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRD,2))));
SINRS1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRS,2))));
SINRO1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRO,2))));
SINRR1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRR,2))));
SINRD2 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRD2,2))));

%MSE
mseg1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(mseg,2))));
msep1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(msep,2))));
msed1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(msed,2))));
mses1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(mses,2))));
mseo1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(mseo,2))));
mser1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(mser,2))));
msed2 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(msed2,2))));

%Power
pwg1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(pwg,2))));
pwp1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(pwp,2))));
pwd1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(pwd,2))));
pws1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(pws,2))));
pwo1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(pwo,2))));
pwr1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(pwr,2))));
pwd2 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(pwd2,2))));

%Norm of weight vector
norg1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(norg,2))));
norp1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(norp,2))));
nord1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(nord,2))));
nors1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(nors,2))));
noro1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(noro,2))));
norr1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(norr,2))));
nord2 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(nord2,2))));


%Plot norm
figure(1);
hng = plot(1:N, norg1,'k',1:100:N,norg1(1:100:N),'d');
hold on;
hnp = plot(1:N, norp1,'k',1:100:N,norp1(1:100:N),'h');
hold on;
hnd = plot(1:N, nord1,'k',1:100:N,nord1(1:100:N),'*');
hold on;
hns = plot(1:N, nors1,'k',1:100:N,nors1(1:100:N),'^');
hold on;
hno = plot(1:N, noro1,'k',1:100:N,noro1(1:100:N),'o');
hold on;
hnd2 = plot(1:N, nord2,'k',1:100:N,nord2(1:100:N),'s');
hold on;
hnr = plot(1:N, norr1,'k',1:100:N,norr1(1:100:N),'+');

legend([hng(2) hnp(2) hno(2) hns(2) hnd(2) hnd2(2) hnr(2)],'Standard MVDR ', 'Standared MVDR-Gen', 'Robust MVDR-WC/SOCP','Robust MVDR-WC/EigDec','Robust MVDR-WC/Proposed','Robust MVDR-WC/Proposed-Gen.','Benchmarck MVDR-Gen');

xlabel('Snapshot');
ylabel('Norm (dB)');
title('Weight Vector Norm'); 

%Plot mse
figure(2);
hmg = plot(1:N, mseg1,'k',1:100:N,mseg1(1:100:N),'d');
hold on;
hmp = plot(1:N, msep1,'k',1:100:N,msep1(1:100:N),'h');
hold on;
hmd = plot(1:N, msed1,'k',1:100:N,msed1(1:100:N),'*');
hold on;
hms = plot(1:N, mses1,'k',1:100:N,mses1(1:100:N),'^');
hold on;
hmo = plot(1:N, mseo1,'k',1:100:N,mseo1(1:100:N),'o');
hold on;
hmd2 = plot(1:N, msed2,'k',1:100:N,msed2(1:100:N),'s');
hold on;
hmr = plot(1:N, mser1,'k',1:100:N,mser1(1:100:N),'+');

legend([hmg(2) hmp(2) hmo(2) hms(2) hmd(2) hmd2(2) hmr(2)],'Standard MVDR ', 'Standared MVDR-Gen', 'Robust MVDR-WC/SOCP','Robust MVDR-WC/EigDec','Robust MVDR-WC/Proposed','Robust MVDR-WC/Proposed-Gen.','Benchmarck MVDR-Gen');

xlabel('Snapshot');
ylabel('MSE (dB)');
title('Mean Squared Error'); 
%Plot SINR

figure(3);
hsg = plot(1:N, SINRG1,'k',1:100:N,SINRG1(1:100:N),'d'); 
hold on;
hsp = plot(1:N, SINRP1,'k',1:100:N,SINRP1(1:100:N),'h'); 
hold on;
hsd = plot(1:N, SINRD1,'k',1:100:N,SINRD1(1:100:N),'*');
hold on;
hss = plot(1:N, SINRS1,'k',1:100:N,SINRS1(1:100:N),'^');
hold on;
hso = plot(1:N, SINRO1,'k',1:100:N,SINRO1(1:100:N),'o');
hold on;
hsd2 = plot(1:N, SINRD2,'k',1:100:N,SINRD2(1:100:N),'s');
hold on;
hsr = plot(1:N, SINRR1,'k',1:100:N,SINRR1(1:100:N),'+');



xlabel('Snapshot');
ylabel('SINR (dB)');
title(' Signal-to-Interference+Noise Ratio'); 
legend([hsg(2) hsp(2) hso(2) hss(2) hsd(2) hsd2(2) hsr(2)],'Standard MVDR ', 'Standared MVDR-Gen', 'Robust MVDR-WC/SOCP','Robust MVDR-WC/EigDec','Robust MVDR-WC/Proposed','Robust MVDR-WC/Proposed-Gen.','Benchmarck MVDR-Gen');

%Plot power
figure(4);
hwg = plot(1:N, pwg1,'k',1:100:N,pwg1(1:100:N),'d');
hold on;
hwp = plot(1:N, pwp1,'k',1:100:N,pwp1(1:100:N),'h');
hold on;
hwd = plot(1:N, pwd1,'k',1:100:N,pwd1(1:100:N),'*');
hold on;
hws = plot(1:N, pws1,'k',1:100:N,pws1(1:100:N),'^');
hold on;
hwo = plot(1:N, pwo1,'k',1:100:N,pwo1(1:100:N),'o');
hold on;
hwd2 = plot(1:N, pwd2,'k',1:100:N,pwd2(1:100:N),'s');
hold on;
hwr = plot(1:N, pwr1,'k',1:100:N,pwr1(1:100:N),'+');

xlabel('Snapshot');
ylabel('SOI Power (dB)');
title(' Signal of Interest Power'); 
legend([hwg(2) hwp(2) hwo(2) hws(2) hwd(2) hwd2(2) hwr(2)],'Standard MVDR ', 'Standared MVDR-Gen', 'Robust MVDR-WC/SOCP','Robust MVDR-WC/EigDec','Robust MVDR-WC/Proposed','Robust MVDR-WC/Proposed-Gen.','Benchmarck MVDR-Gen');


%array pattern plot
iter =0;
RP = [];
H=[];
H1 = [];
A = [];

for dtheta=-90:1:90 
    thetar=dtheta*(pi/180);     % Angle in radians
    iter=iter+1;
    %calcuate steering vector at certain direction for interested signal;
        %for j=1:M
        %   PB(j,1)=exp((j-1)*i*2*pi*d*sin(thetar));
        %end
    for j=1:M
        P(j,1) = exp((j-1)*i*2*pi*d*sin(thetar)); %main path
        Ptot(j,1) =  P(j,1);
        for f=1:2 
            %phi(f) = 2*pi*rand(1); %generate phase of multipathes paths. 
            P1(j,f) =exp((j-1)*i*2*pi*d*sin(DOA(f)));
            Ptot(j,1) = Ptot(j,1)+ 0.4*P1(j,f); 
        end;
    end

    RP = [P(:,1) P1(:,1:f)]; %generalized steering vector matrix with m*ml dimension
    A = [RP P(:,2) P(:,3)]; %
    H = [A1*P(:,1), A2*P(:,2), A3*P(:,3)];%construct new system matrix
    H1 =  [A1*A(:,1), 0.4*A1*A(:,2), 0.4*A1*A(:,3), A2*A(:,4), A3*A(:,5)];
       
        %gp(iter) = 10*log10(abs(SINRF(wp,H1,Ndb,1))); %calculate gain of standared Capon 
        %gd(iter) = 10*log10(abs(SINRF(wd,H1,Ndb,1))); %calculate gain of conventional
        %gs(iter) = 10*log10(abs(SINRF(ws,H1,Ndb,1))); %calculate gain of Robust Capon
        %go(iter) = 10*log10(abs(SINRF(wo,H1,Ndb,1))); %calculate gain of Robust Capon
        
     gg(iter) =10*log10(abs(SINRF(wg,H,Ndb,1)));             % SINR of standared capon beamformer with single constraint          
     gp(iter) =10*log10(abs(SINRFm(wp,H1,Ndb)));             % SINR of standared capon beamformer   with multiple constrint        
     gd(iter) =10*log10(abs(SINRFm(wd,H1,Ndb)));
     gs(iter) =10*log10(abs(SINRF(ws,H,Ndb,1)));
     go(iter) =10*log10(abs(SINRF(wo/norm(wo),H,Ndb,1)));
     gr(iter) =10*log10(abs(SINRFm(wr,H1,Ndb)));
     gd2(iter)=10*log10(abs(SINRFm(wd2,H1,Ndb)));
        
        %gg(iter) = 10*log10((real(wg'*PB))^2); %calculate gain of standared Capon 
        %gp(iter) = 10*log10((real(wp'*PB))^2); %calculate gain of standared Capon 
        %gd(iter) = 10*log10((real(wd'*PB))^2); %calculate gain of conventional
        %gs(iter) = 10*log10((real(ws'*PB))^2); %calculate gain of Robust Capon
        %go(iter) = 10*log10((real(wo'*PB))^2); %calculate gain of Robust Capon
        %gr(iter) = 10*log10((real(wr'*PB))^2); %calculate gain of Robust Capon
        %gd2(iter) = 10*log10((real(wd2'*PB))^2); %calculate gain of Robust Capon
       
end
  
mno = max([norm(gg), norm(gp),norm(gd),norm(gs),norm(go), norm(gr), norm(gd2)]);    

%gp =mno*(gp/norm(gp)); 
%gd =mno*(gd/norm(gd));
%gs =mno*(gs/norm(gs));
%go =mno*(go/norm(go));


f = [max(gg), max(gp),max(gd),max(gs),max(go),max(gr), max(gd2)];
lim = max(f);
ggp = gg-max(gg);
gpp = gp-max(gp); 
gdp = gd-max(gd);  
gsp = gs-max(gs);
gop = go-max(go);
grp = gr-max(gr);
gd2p= gd2-max(gd2);

%plot battern in Horizental
figure(5);
h1 = plot([-90:1:90]*pi/180,ggp,'r'); 
hold on;
h2 = plot([-90:1:90]*pi/180,gpp,'k');  
hold on;
h3 = plot([-90:1:90]*pi/180,gdp,'b'); 
hold on;
h4 = plot([-90:1:90]*pi/180,gsp,'g'); 
hold on;
h5 = plot([-90:1:90]*pi/180,gop,'m'); 
hold on;
h6 = plot([-90:1:90]*pi/180,grp,'c');
hold on;
h7 = plot([-90:1:90]*pi/180,gd2p,'y');


hold on;
q = axis;
plot(theta1,q(3):0.1:q(4));
hold on;
plot(theta2,q(3):0.1:q(4));
hold on;
plot(theta3,q(3):0.1:q(4));
hold on;
plot(DOA(1),q(3):0.1:q(4));
hold on;
plot(DOA(2),q(3):0.1:q(4));


legend([h1 h2 h3 h4 h5 h6 h7],'Standard MVDR ', 'Standared MVDR-Gen', 'Robust MVDR-WC/SOCP','Robust MVDR-WC/EigDec','Robust MVDR-WC/Proposed','Robust MVDR-WC/Proposed-Gen.','Benchmarck MVDR-Gen');


