function tw = newton2(PP1,w,u,ep,L)

z,gm,ep,a,dl);
% z = U^H*as eigenvector multiplied by steering vector
% gm is the eigenvalue diagonal matrix
% ep is the uncertainity value
% a is the presumed steering vector

i = 2;

tw(i) = (norm(a)-ep)/(min(gm)+dl); %statrt value for landa with maximum value

tw(i-1) = tw(i)+0.000002;

while tw(i-1)-tw(i) > 0.000001 %check for tolerance factor
        
        tt = tw(i)+ 0.01*(sum((abs(z).^2)./((ep+tw(i)*(gm+dl)).^2))-1)...
        /(sum(((abs(z).^2).*(gm+dl))./((ep+tw(i)*(gm+dl)).^3)));  %update diagonal loading term using newton equation
        i=i+1;
        tw(i) = tt;
        
   % end
end
%tw1 = tw(i); 


