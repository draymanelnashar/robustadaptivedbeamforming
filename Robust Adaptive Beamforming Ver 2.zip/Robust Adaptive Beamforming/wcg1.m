function gr = wcg (PP1,w,u,ep,L)

w1=w+u*PP1*L;
gr=real(PP1'*w1)-ep'*norm(w1)-II;
end

