clear all;
close all;
mc = 0;
M = 5;                                      % Elements in array
d = 0.5;                                    % sensor spacing half wavelength wrt wc
N = 1000;                                   % number of samples  
Ndb	=0;                                  % kind of noise level in dB
f1 = 0.03 ;                                 % frequancy of S1
f2 = 0.02 ;                                 % frequancy of S2
f3 = 0.01;                                  % frequancy of S2
A1 =10^(5/20);                              % Amplitude of sinusoid (required)
A2 =10^(10/20);                             % Amplitude of first sinterfernce (10 db stronger) 
A3 =10^(10/20);                             % Amplitude of second sinterfernce (10 db stronger)  
L = 3;                                      % number of sources
VL = 1;
alfa = 0.2;
theta1 = 0;                                 % Direction of arrival of interested signal
theta2 = pi/6;                              % Second direction of arrival for first interfernce
theta3 = pi/3;                              % thired direction of arrival for second interfernce 
zeta = 1;                                   % inverse matrix initialization
Ln = 1;                                     % define the forgetting factor  
ff = 0.97;                                  % Forgetting factorof subspace traking algorithm
dl = 0;
ep1 = 1;                                  % tolerance value for the proposed
ep2 = 1;                                    % tolerance value for the robust with eigendecomposition
ep3 = 3;                                    % tolerance value for SOCP
ep4 = 1.8;                                    % tolerance value for new robust detector  
ep5 = 3;
G = 0;                                      % initalize QI constraint gradient
it = 0;                                     % This counter for number of VL subrouting excution
it1 = 0;
itr1 = 0;
alfa1 = 0.008;                               % initalize the coffeiant of step-size                                    % proposed Variable loading Technique 
alfa3 =0.01;
QE = [];
misang = 0.03*pi;                           % mismatch angle
%misang = 0;

%define source signal
s1	= A1*cos(2*pi*f1*(1:N)) ;
s2	= A2*sign(cos(2*pi*f2*(1:N)));

s3	= A3*sign(randn(1,N)) ;

S	= [ s1 ; s2 ; s3 ] ;                %source signal with dimention L*N rows of signal
noiseamp = 10^(Ndb/20)/sqrt(2);      %noise amplitude for complex noise
V=noiseamp*randn(M,N)+i*noiseamp*randn(M,N); %noise process generaation 

%Intialize steering vectors
P=zeros(M,L);  

%generate steering vectors
for j=1:M
   P(j,1)=exp((j-1)*i*2*pi*d*sin(theta1));
end
for j=1:M
   P(j,2)=exp((j-1)*i*2*pi*d*sin(theta2));
end
for j=1:M
   P(j,3)=exp((j-1)*i*2*pi*d*sin(theta3));
end
Pa = P(:,1);  %save correct DOA
% generate recived signal vectors from antenna array 
X = P*S+V ;%recived signal with dimention M*N
H = [A1*P(:,1), A2*P(:,2), A3*P(:,3)];
%add mismatch error to steering vector by 
for j=1:M
   P(j,1)=exp((j-1)*i*2*pi*d*sin(theta1+misang));
end
 
as = (P(:,1)/norm(P(:,1)))*M; %normalize the presumed steering vector for SOCP


%H = [A1*P(:,1), A2*P(:,2), A3*P(:,3)]; %generate mixing matrix which including the amplitudes
Pr = P(:,1);  %initialize the robust steering vector; 

%Pc1 = eye(M)-(C*C')/real((C'*C)); %Projection matrix for conventional capon beamforming
%Pc2 = eye(M)-(Pr*Pr')/real((Pr'*Pr)); 


IR = zeta*eye(M);                           % initalize the inverse autocorrelation matrix
Rs = (1/zeta)*eye(M);                       % initalize the inverse autocorrelation matrix
R_v = 10^(Ndb/10)*eye(M,M);        %noise matrix
IR_v= pinv(R_v);

for k = 1:N 
    r = X(:,k); %take one snapshot receiving vector
    Rs  = Ln*Rs + r*r';         
    dem = real(1/(Ln+ r'*IR*r));            % 
    Kn = dem*IR*r;                          % Kalaman gain        % autocorrelation matrix of recived signal    
    IR = (1/Ln)*(IR - Kn*r'*IR);            % update inverse of Autocorrolation matrix 
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    as1 = P(:,1); %orginal steering vector 
    %as1 = Pr;
    if k==1
    wd = IR*as1;%/(real(as1'*IR*as1)); % initalize new robust detector.
    %wd = as1;
    end
    as2 = (as1- ep5*(wd/norm(wd))); %modified steering vector
    grd=Rs*wd;%-as2;
    mu2 = alfa3*(norm(grd))^2/(real(grd'*Rs*grd)+0.000000001);
    %mu2 = 0.00001;
    wd1 = wd-mu2*grd; %initial weight vector without robustness
    if real(wd1'*as1) < ep5*norm(wd1)+1 %check for robustness condition 
        A1 = mu2^2*((real(as2'*as1))^2-ep5^2*((norm(as2))^2));
        B1 = mu2*(real(wd1'*as1-1)*real(as2'*as1)-ep5^2*real(wd1'*as2));
        C1 = (real(wd1'*as1)-1)^2-ep5^2*norm(wd1)^2;
        if A1<0 && (B1^2<A1*C1)
            ep5 = ep5-0.1;
        end  
        landa3 = (-B1+(B1^2-A1*C1)^0.5)/A1; 
        wd = wd1+mu2*landa3*as2;
         itr1 = itr1 +1;
        QE = [QE; A1 B1 C1 landa3 norm(wd)];
    else
        wd = wd1;
        landa3 = 0;
        QE = [QE; 0 0 0 0 norm(wd)];
    end
  
    SINRD(k) = SINRF(wd,H,Ndb,1);            
    
    end

%Smoothing and averaging over montcarlo simulation
%Butter worht smoothing Filter
[filt_num,filt_den] = butter(1,10^(-2));

SINRD1 = 10*log10(abs(filtfilt(filt_num,filt_den,SINRD)));


figure(1);
h1 = plot(1:N, SINRD1,'k',1:100:N,SINRD1(1:100:N),'dk'); 


xlabel('Snapshot');
ylabel('SINR (dB)');
title(' Signal-to-Interference+Noise Ratio'); 

M = size(QE(:,1),1);
%Plot WC parameters
figure(5);
title('WC Constraint Parameters'); 
subplot(2,2,1)
hda = plot(1:M, QE(1:M,1),'b',1:100:M,QE(1:100:M,1),'*b');
xlabel('Snapshot');
title('A'); 
subplot(2,2,2)
hdb = plot(1:M, QE(1:M,2),'b',1:100:M,QE(1:100:M,2),'*b');
xlabel('Snapshot');
title('B'); 
subplot(2,2,3)
hdc = plot(1:M, QE(1:M,3),'b',1:100:M,QE(1:100:M,3),'*b');
xlabel('Snapshot');
title('C'); 
subplot(2,2,4)
hdl = plot(1:M, QE(1:M,4),'b',1:100:M,QE(1:100:M,4),'*b');
xlabel('Snapshot');
title('\lambda'); 