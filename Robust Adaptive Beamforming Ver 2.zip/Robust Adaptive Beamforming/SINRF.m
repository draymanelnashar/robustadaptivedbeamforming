function SINR =SINRF(W,H,SNR,user)
sigma2_n=10^(SNR/10);       %noise power  
[M K] = size(H);            %K number of signals
dem = abs(sigma2_n*(W'*W)); %noise power after beamformer
for j = 1:K
    h = H(:,j);             %pick up the steering of the corresponding usignal
    if j == user
        %calculate power of required user
        num = (abs(h'*W))^2;
    else
        %calculate interfernce power
        dem = dem + abs(W'*h*h'*W);
    end
end
SINR = num/dem;

