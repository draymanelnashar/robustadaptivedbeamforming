clear all;
close all;
%start montcarlo simulation
for mc = 1:10
M = 5;                                      % Elements in array
d = 0.5;                                    % sensor spacing half wavelength wrt wc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Mutual Coupling Matrix
a = 0.001*ones(1,M);                        % Antenna Radii
L = 0.5*ones(1,M);                          % Vector of antenna lenghts
dist =(0:M-1)*d;                            % equally-spaced with ?/2 spacing
Z=impedmat(L,a,dist);                       % Mutual Impeadance Matrix
Za=Z(1,1);                                  % element?s impedance in isolation with ?/2 spacing 
Zt=Za';                                     % Impedance of the receiver at each element and is chosen as the complex conjugate of Za    
C = (Za+Zt)*pinv(Z+Zt*eye(5));              % Mutual Coupling Matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

N = 1000;                                   % number of samples  
Ndb	= -40;                                  % kind of noise level in dB
f1 = 0.01 ;                                 % frequancy of S1
f2 = 0.02 ;                                 % frequancy of S2
f3 = 0.03;                                  % frequancy of S2
A1 =10^(0/20);                              % Amplitude of sinusoid (required)
A2 =10^(10/20);                             % Amplitude of first sinterfernce (10 db stronger) 
A3 =10^(10/20);                             % Amplitude of second sinterfernce (10 db stronger)  
L = 3;                                      % number of sources
VL = 1;
alfa = 0.3;
theta1 = 0;                                 % Direction of arrival of interested signal
theta2 = pi/4;                              % Second direction of arrival for first interfernce
theta3 = pi/6;                              % thired direction of arrival for second interfernce 
zeta = 1;                                   % inverse matrix initialization
Ln = 1;                                     % define the forgetting factor  
ff = 0.97;                                  % Forgetting factorof subspace traking algorithm
En = orth(rand(M,M-L)+i*rand(M,M-L));       % inialaize eigenvector matrix with orthogonal matrix
Es = orth(rand(M,L)+i*rand(M,L));           % inialaize eigenvector matrix with orthogonal matrix
%EV = (10^(Ndb/20)/sqrt(2)M)*eye(M);        % inialaize eigenvalues matrix 
ep1 = 0.5;                                  % tolerance value for the proposed
ep2 = 0.5;                                  % tolerance value for the robust with eigendecomposition
ep3 = 1.55;                                 % tolerance value for SOCP
G = 0;                                      % initalize QI constraint gradient
it = 0;                                     % This counter for number of VL subrouting excution
it1 = 0;
wp = zeros(M,1);                            % initialize the conventional capon 
IR = zeta*eye(M);                           % initalize the inverse autocorrelation matrix
Rs = (1/zeta)*eye(M);                       % initalize the inverse autocorrelation matrix
alfa1 = 0.006;                              % initalize the coffeiant of step-size                                    % proposed Variable loading Technique 
misang = 0.03*pi;                           % mismatch angle
%misang = 0;
diagl = 0;                                  % fixed diagonal loadingterm for SOCP


%define source signal
s1	= A1*cos(2*pi*f1*(1:N)) ;
s2	= A2*sign(cos(2*pi*f2*(1:N)));
%s3	= A3*(cos(2*pi*f3*(1:N))) ;
s3	= A3*sign(randn(1,N)) ;

S	= [ s1 ; s2 ; s3 ] ;                %source signal with dimention L*N rows of signal
noiseamp = 10^(Ndb/20)/sqrt(2);      %noise amplitude for complex noise
V=noiseamp*randn(M,N)+i*noiseamp*randn(M,N); %noise process generaation 

%Intialize steering vectors
P=zeros(M,L);  

%generate steering vectors
for j=1:M
   P(j,1)=exp((j-1)*i*2*pi*d*sin(theta1));
end
for j=1:M
   P(j,2)=exp((j-1)*i*2*pi*d*sin(theta2));
end
for j=1:M
   P(j,3)=exp((j-1)*i*2*pi*d*sin(theta3));
end

P = C*P;     %Add effect of mutual coupling for all steering vectors of incident signals
Pa = P(:,1);  %save correct DOA
% generate recived signal vectors from antenna array 
X = P*S+V ;%recived signal with dimention M*N
H = [A1*P(:,1), A2*P(:,2), A3*P(:,3)];
%add mismatch error to steering vector by 
for j=1:M
   P(j,1)=exp((j-1)*i*2*pi*d*sin(theta1+misang));
end
 
as = (P(:,1)/norm(P(:,1)))*M; %normalize the presumed steering vector for SOCP
%P(:,1) = as;
%Conventional  Beamformer 
R_v = 10^(Ndb/10)*eye(M,M);        %noise matrix
IR_v= inv(R_v);
pwc = 1/((P(:,1))'*IR_v*(P(:,1))); %output power 
Ko = P(:,1)'*IR_v*pwc;             %Optimal gain vector (Capon beamformer) 

%adaptive beamforming start now (capon beamforming)
% initialaize the beamformer
wc = P(:,1)/M; % conventional beamformer;
%H = [A1*P(:,1), A2*P(:,2), A3*P(:,3)]; %generate mixing matrix which including the amplitudes
Pr = P(:,1);  %initialize the robust steering vector; 
%C =P(:,1); 
%Pr = zeros(M,1);
Gr = IR*Pr;   %initialize the gradient; 
%Pc1 = eye(M)-(C*C')/real((C'*C)); %Projection matrix for conventional capon beamforming
%Pc2 = eye(M)-(Pr*Pr')/real((Pr'*Pr)); 
for k = 1:N 
    r = X(:,k); %take one snapshot receiving vector
    Rs  = Ln*Rs + r*r';                     % autocorrelation matrix of recived signal  
    dem = real(1/(Ln+ r'*IR*r));            % 
    Kn = dem*IR*r;                          % Kalaman gain        
    IR = (1/Ln)*(IR - Kn*r'*IR);            % update inverse of Autocorrolation matrix 
    D = Gr+G;                               % update the previous gradient with Diagonal loading term
    mu = real((alfa1*D'*D)/(real(D'*IR*D)+0.00000001)); % update the step size 
    Gr = IR'*Pr;                            % Calculate the gradient 
    %mu = real((alfa1*Gr'*Gr)/(real(Gr'*IR*Gr)+0.00000001)); 
    pp1 = Pr-P(:,1);                        % it must satisfy the constraint 
    Pr1= Pr - mu*Gr;                        % update the robust steering vector w/t QI constraint  
    pp2 = Pr1-P(:,1);                       % calculate the difference with known steering vector
    if (norm(pp2)^2)> ep1                   % check for QC condition on pp vector1  
                cc = pp2'*pp2-ep1;                                    % positive
                bb = 2*mu*real(pp2'*pp1);                             % positive
                aa = (mu^2)*(pp1'*pp1);                               % positive
                landa = (bb-real(((bb^2)-(4*aa*cc))^0.5))/(2*aa);     % estimate diagonal Loading term
                Pr1 = Pr -mu*Gr-mu*landa*pp1;                         % apply Quadritic inquallity constrain
                G = landa*pp1;                                        % gradient of QC term to be added in advance  
                it = it+1;
            else
        G = 0;
    end
    %end
    Pr = Pr1; % steering vector of robust proposed technique
    %performing robust of compared algorithm   
    %IRs = inv(Rs);
    [U,D] = eig(Rs);                                    % get eigen vectors and values of autocorrelation matrix
    gm = real(diag(D));                                 % get eigenvalues in one vector
    z = U'*P(:,1);                                      % get vecotr to estimate the diagonal loading term
    landa1 = newton1(z,gm,ep2,P(:,1));                  % get the diagonal loading term by newton method
    Pd = P(:,1) - (inv(eye(M)+landa1*Rs))*P(:,1);       % get equivalent steering vector with uncertainities   
    Es = NOOjacom(r,Es,1,0.001,0.01);                  % Signal subspace tracking
    En = NOOjacom(r,En,-1,0.001,0.01);                  % noise subspace tracking 
    %En = flipdim(En,2);
    Es = flipdim(Es,2);
    E = [En Es];                                        % combine signal subspaces
    EV = real(diag(E'*Rs*E));               
    E1 = E'*P(:,1);                                     % get vecotr to estimate the diagonal loading term
    landa2 = newton1(E1,EV,ep2,P(:,1));                 % get the diagonal loading term by newton method
    Ps = P(:,1) - (inv(eye(M)+landa2*Rs))*P(:,1);       % get equivalent steering vector with uncertainities
    
    if mod(k-1,10)==0
    %as = (Pr/norm(Pr))*M;     
    %SOCP using SeDuMi software package 
       [wo] = robustbeam(Rs,as,ep3,diagl);
    end
    
    %Power
    pwp(k,mc) = 1/(real(P(:,1)'*IR*P(:,1)));               % output power of standared beamformer
    pwr(k,mc) = 1/(real(Pr'*IR*Pr));                       % output power of robust beamformer
    pwd(k,mc) = 1/(real(Pd'*IR*Pd));                       % 
    pws(k,mc) = 1/(real(Ps'*IR*Ps));   
    pwo(k,mc) = real(wo'*Rs*wo);                           % o/p power of SOCP
    
    %Beamformer
    wr = (IR*Pr)*pwr(k,mc);                     % robust Capon beamforming
    wp = (IR*P(:,1))*pwp(k,mc);                 % conventional capon beamformer 
    wd = (IR*Pd)*pwd(k,mc);                     % robust2 capon beamforming
    ws = (IR*Ps)*pws(k,mc);
    % generate new joint constraint detector
    wj = wr; %initalize the joint constraint detector
    if (norm(wj)^2)> alfa 
        switch VL
            case 1
                Va = IR*wj;
                a = norm(Va)^2;
                b = -2*real(Va'*wj);
                c = norm(wj)^2-alfa;
                gama = (1/(2*a))*(-b-real((b^2-4*a*c)^0.5));
                wj = wj - gama*Va;
            case 2
                wsp = alfa*(wj/norm(wj));
            case 3
        end    
    end 
    
    pwj(k,mc) = real(wj'*Rs*wj);  
    %Array Gain
    gnp(k,mc) = ((abs( wp'*Pa)).^2)/(real(wp'*R_v*wp));
    gnr(k,mc) = ((abs( wr'*Pa)).^2)/(real(wr'*R_v*wr));
    gnd(k,mc) = ((abs( wd'*Pa)).^2)/(real(wd'*R_v*wd));
    gns(k,mc) = ((abs( ws'*Pa)).^2)/(real(ws'*R_v*ws));
    gno(k,mc) = ((abs( wo'*Pa)).^2)/(real(wo'*R_v*wo)); 
    gnj(k,mc) = ((abs( wj'*Pa)).^2)/(real(wj'*R_v*wj)); 
    
    %SINR
    SINRP(k,mc) = SINRF(wp,H,Ndb,1);             % SINR of standared capon beamformer 
    SINRR(k,mc) = SINRF(wr,H,Ndb,1);             % SINR of robust capon beamformer 
    SINRD(k,mc) = SINRF(wd,H,Ndb,1);
    SINRS(k,mc) = SINRF(ws,H,Ndb,1);
    SINRO(k,mc) = SINRF(wo,H,Ndb,1);
    SINRJ(k,mc) = SINRF(wj,H,Ndb,1);
    
    %Output
    op1(k,mc) = real(wp'*X(:,k));               % o/p signal of capon beamforming
    op2(k,mc) = real(wc'*X(:,k));               % o/p signal of conventional beamforming
    op3(k,mc) = real(wr'*X(:,k));               % o/p robust of capon beamforming
    op4(k,mc) = real(wd'*X(:,k));               % o/p of robust2 beamforming
    op5(k,mc) = real(ws'*X(:,k));  
    op6(k,mc) = real(wo'*X(:,k)); 
    op7(k,mc) = real(wj'*X(:,k)); 
    
    %MSE
    msep(k,mc) = (op1(k)-s1(k))^2;              % MSE of capon beamforming
    msec(k,mc) = (op2(k)-s1(k))^2;              % MSE of conventional beamforming  
    mser(k,mc) = (op3(k)-s1(k))^2;              % MSE of robust capon beamforming
    msed(k,mc) = (op4(k)-s1(k))^2;              % MSE of robust2 capon beamforming
    mses(k,mc) = (op5(k)-s1(k))^2;
    mseo(k,mc) = (op6(k)-s1(k))^2;
    msej(k,mc) = (op7(k)-s1(k))^2;
end
%fprintf('The # of VL subrotuine for the run # %d is %d \n', mc,it-it1)
it1 = it;
end
fprintf('The average # of VL subrotuine over all runs is %f \n', it/mc)
%Smoothing and averaging over montcarlo simulation
%Butter worht smoothing Filter
[filt_num,filt_den] = butter(1,10^(-2.2));
%SINR
SINRP1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRP,2))));
SINRR1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRR,2))));
SINRD1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRD,2))));
SINRS1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRS,2))));
SINRO1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRO,2))));
SINRJ1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRJ,2))));
%MSE
msep1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(msep,2))));
mser1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(mser,2))));
msed1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(msed,2))));
mses1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(mses,2))));
mseo1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(mseo,2))));
msej1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(msej,2))));
%Power
pwp1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(pwp,2))));
pwr1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(pwr,2))));
pwd1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(pwd,2))));
pws1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(pws,2))));
pwo1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(pwo,2))));
pwj1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(pwj,2))));
%array gain
gnp1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(gnp,2))));
gnr1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(gnr,2))));
gnd1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(gnd,2))));
gns1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(gns,2))));
gno1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(gno,2))));
gnj1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(gnj,2))));

%plot array gain
figure(1);
gnp = plot(1:N, gnp1,'r');
hold on;
gnd = plot(1:N, gnd1,'g');
hold on;
gns = plot(1:N,gns1,'b');
hold on;
gnr = plot(1:N, gnr1,'k');
hold on;
gno = plot(1:N, gno1,'m');
hold on;
gnj = plot(1:N, gnj1,'c');

legend([gnp gnd gns gno gnr gnj],'Standared Capon','Robust Capon (Batch)',...
    'Robust Capon (SS)','Robust (SOCP)','Proposed1','Proposed2');
xlabel('Iterations (n)');
ylabel('Array Gain (dB)');
title('Array Gain'); 

%Plot mse
figure(2);
hmp = plot(1:N, msep1,'k',1:100:N,msep1(1:100:N),'d');
hold on;
hmd = plot(1:N, msed1,'k',1:100:N,msed1(1:100:N),'*');
hold on;
hms = plot(1:N, mses1,'k',1:100:N,mses1(1:100:N),'^');
hold on;
hmr = plot(1:N, mser1,'k',1:100:N,mser1(1:100:N),'p');
hold on;
hmo = plot(1:N, mseo1,'k',1:100:N,mseo1(1:100:N),'o');
hold on;
hmj = plot(1:N, msej1,'k',1:100:N,msej1(1:100:N),'s');

legend([hmp(2) hmd(2) hms(2) hmo(2) hmr(2) hmj(2)],'Standared Capon','Robust Capon (Batch)',...
    'Robust Capon (SS)','Robust (SOCP)','Proposed1','Proposed2');
xlabel('Iterations (n)');
ylabel('MSE (dB)');
title('Mean Squared Error'); 
%Plot SINR

figure(3);
hsp = plot(1:N, SINRP1,'k',1:100:N,SINRP1(1:100:N),'d'); 
hold on;
hsd = plot(1:N, SINRD1,'k',1:100:N,SINRD1(1:100:N),'*');
hold on;
hss = plot(1:N, SINRS1,'k',1:100:N,SINRS1(1:100:N),'^');
hold on;
hsr = plot(1:N, SINRR1,'k',1:100:N,SINRR1(1:100:N),'p');
hold on;
hso = plot(1:N, SINRO1,'k',1:100:N,SINRO1(1:100:N),'o');
hold on;
hsj = plot(1:N, SINRJ1,'k',1:100:N,SINRJ1(1:100:N),'s');

xlabel('Iterations (n)');
ylabel('SINR (dB)');
title(' Signal-to-Interference+Noise Ratio'); 
legend([hsp(2) hsd(2) hss(2) hso(2) hsr(2) hsj(2)],'Standared Capon','Robust Capon (Batch)',...
    'Robust Capon (SS)','Robust (SOCP)','Proposed1','Proposed2');

%Plot power
figure(4);
hwp = plot(1:N, pwp1,'k',1:100:N,pwp1(1:100:N),'d');
hold on;
hwd = plot(1:N, pwd1,'k',1:100:N,pwd1(1:100:N),'*');
hold on;
hws = plot(1:N, pws1,'k',1:100:N,pws1(1:100:N),'^');
hold on;
hwr = plot(1:N, pwr1,'k',1:100:N,pwr1(1:100:N),'p');
hold on;
hwo = plot(1:N, pwo1,'k',1:100:N,pwo1(1:100:N),'o');
hold on;
hwj = plot(1:N, pwj1,'k',1:100:N,pwj1(1:100:N),'s');

xlabel('Iterations (n)');
ylabel('SOI Power (dB)');
title(' Signal of Interest Power'); 
legend([hwp(2) hwd(2) hws(2) hwo(2) hwr(2) hwj(2)],'Standared Capon','Robust Capon (Batch)',...
    'Robust Capon (SS)','Robust (SOCP)','Proposed1','Proposed2')

%array pattern plot
iter =0;
for dtheta=-90:1:90 
    thetar=dtheta*(pi/180);     % Angle in radians
    iter=iter+1;
    %calcuate steering vector at certain direction for interested signal;
        for j=1:M
           P(j,1)=exp((j-1)*i*2*pi*d*sin(thetar));
        end
        
        %p1(j)=exp((j-1)*i*2*pi*d*sin(theta));
        H1 = [A1*P(:,1), A2*P(:,2), A3*P(:,3)];%construct new system matrix
        
        gp(iter) = 10*log10(abs(SINRF(wp,H1,Ndb,1))); %calculate gain of standared Capon 
        gd(iter) = 10*log10(abs(SINRF(wd,H1,Ndb,1))); %calculate gain of conventional
        gs(iter) = 10*log10(abs(SINRF(ws,H1,Ndb,1))); %calculate gain of Robust Capon
        gr(iter) = 10*log10(abs(SINRF(wr,H1,Ndb,1))); %calculate gain of Robust Capon
        go(iter) = 10*log10(abs(SINRF(wo,H1,Ndb,1))); %calculate gain of Robust Capon
        gj(iter) = 10*log10(abs(SINRF(wj,H1,Ndb,1))); %calculate gain of Robust Capon
    end
    
gp =norm(gr)*(gp/norm(gp)); 
gd =norm(gr)*(gd/norm(gd));
gs =(norm(gr)*gs/norm(gs));
go =(norm(gr)*go/norm(go));
gj =(norm(gr)*gj/norm(gj));
gr =gr;

f = [max(gp),max(gd),max(gs),max(gr),max(go), max(gj)];
lim = max(f);
gpp = gp-lim; 
gdp = gd-lim;  
gsp = gs-lim;
grp = gr-lim;
gop = go-lim;
gjp = gj-lim;
%plot battern in Horizental
figure(5);
h1 = plot([-90:1:90]*pi/180,gpp,'r');  
hold on;
h2 = plot([-90:1:90]*pi/180,gdp,'g'); 
hold on;
h3 = plot([-90:1:90]*pi/180,gsp,'b'); 
hold on;
h4 = plot([-90:1:90]*pi/180,gop,'m'); 
hold on;
h5 = plot([-90:1:90]*pi/180,grp,'k'); 
hold on;
h6 = plot([-90:1:90]*pi/180,gjp,'c'); 

hold on;
q = axis;
plot(theta1,q(3):0.1:q(4));
hold on;
plot(theta2,q(3):0.1:q(4));
hold on;
plot(theta3,q(3):0.1:q(4));

legend([h1 h2 h3 h4 h5 h6],'Standared Capon','Robust Capon (Batch)','Robust Capon (SS)',...
    'Robust (SOCP)','Proposed1','Proposed2');


