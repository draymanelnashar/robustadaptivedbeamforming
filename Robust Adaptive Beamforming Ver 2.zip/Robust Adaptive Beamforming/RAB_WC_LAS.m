clear all;
close all;
%start montcarlo simulation
for mc = 1:1
M = 5;                                      % Elements in array
d = 1/2;                                    % sensor spacing half wavelength wrt wc
N = 1000;                                   % number of samples  
Ndb	= 0;                                  % kind of noise level in dB
f1 = 0.03 ;                                 % frequancy of S1
f2 = 0.02 ;                                 % frequancy of S2
f3 = 0.01;                                  % frequancy of S2
A1 =10^(5/20);                              % Amplitude of sinusoid (required)
A2 =10^(10/20);                             % Amplitude of first sinterfernce (10 db stronger) 
A3 =10^(10/20);                             % Amplitude of second sinterfernce (10 db stronger)  
L = 3;                                            % number of sources
ml = 3;                                            %number of multipathes 
VL = 1;
alfa = 0.1;
theta1 = 0;                                 % Direction of arrival of interested signal
theta2 = pi/6;                              % Second direction of arrival for first interfernce
theta3 = pi/3;                              % thired direction of arrival for second interfernce 
zeta = 1;                                   % inverse matrix initialization
Ln = 1;                                     % define the forgetting factor  
ff = 0.97;                                  % Forgetting factorof subspace traking algorithm
dl = 0;
ep1 = 2;                                    % tolerance value for the ellipsoidal
ep2 = 2;                                    % tolerance eigendecoposition 
ep3 = 3;                                    % tolerance value for SOCP
ep4 = 1.5;                                    % tolerance value for eigendecoposition
ep5 = 1.5;                                  % tolerance for the proposed algorithm 
ep6 = [1.7 0.2 0.2];                           %equal gain combining constrained vector
L0 = [0.1;0.1;0.1];
II = [1 .5 .5];        
g1 =[1; 0.16 ; 0.16];
G = 0;                                      % initalize QI constraint gradient
it = 0;                                     % This counter for number of VL subrouting excution
it1 = 0;
wp = zeros(M,1);                            % initialize the conventional capon 
IR = zeta*eye(M);                           % initalize the inverse autocorrelation matrix
Rs = (1/zeta)*eye(M);                       % initalize the inverse autocorrelation matrix
alfa1 = 0.01;                               % initalize the coffeiant of step-size                                    % proposed Variable loading Technique 
alfa3 =0.1;                                 % step size factor of proposed algorithm 
alfa4 = 0.3;
misang = 0.03*pi;                           % mismatch angle
misang1 = 0.01*pi;
%misang1 = 0;
iter = [];
diagl = 0;                                  % fixed diagonal loadingterm for SOCP
QE = [];
%define source signal
s1	= A1*cos(2*pi*f1*(1:N)) ;
s2	= A2*sign(cos(2*pi*f2*(1:N)));
%s3	= A3*(cos(2*pi*f3*(1:N))) ;
s3	= A3*sign(randn(1,N)) ;

Stot = [ s1 ; s2 ; s3 ] ;    

S	= [ s1 ; 0.4.*s1; 0.4.*s1 ;s2 ; s3 ] ;                %source signal with dimention L*N rows of signal
noiseamp = 10^(Ndb/20)/sqrt(2);      %noise amplitude for complex noise
V=noiseamp*randn(M,N)+i*noiseamp*randn(M,N); %noise process generaation 

%Intialize steering vectors
P=zeros(M,L);  
DOA(1) = theta1 - 30*pi/180; %generat  DOAs of multipathes componenet 
DOA(2) = theta1 - 80*pi/180;

%generate actual steering vectors 
phs(1)= rand(1)*pi; % phase shift due to delay
phs(2) =- rand(1)*pi;  %phase shift due to delay
phs(3) =rand(1)*pi; 
%phs(1) =0;
%phs(2) =0;
%phs(3) =0;

for j=1:M
   P(j,1) = exp(i*phs(3))*exp((j-1)*i*2*pi*d*sin(theta1)); %main path
   Ptot(j,1) =  P(j,1);
   for f=1:2 
       %phi(f) = 2*pi*rand(1); %generate phase of multipathes paths. 
       P1(j,f) =exp(i*phs(f))*exp((j-1)*i*2*pi*d*sin(DOA(f)));
       Ptot(j,1) = Ptot(j,1)+ 0.4*P1(j,f); 
   end;
end

 RP = [P(:,1) P1(:,1:f)]; %generalized steering vector matrix with m*ml dimension


for j=1:M
   P(j,2)=exp((j-1)*i*2*pi*d*sin(theta2));
end
for j=1:M
   P(j,3)=exp((j-1)*i*2*pi*d*sin(theta3));
end

Pa = P(:,1);  %save correct DOA
% generate recived signal vectors from antenna array 
Ptot(:,2:3)=[P(:,2) P(:,3)] ;
X = Ptot*Stot+V ;%recived signal with dimention M*N withou

A = [RP P(:,2) P(:,3)]; %

%X = A*S + V;
H = [A1*P(:,1), A2*P(:,2), A3*P(:,3)];

H1 =  [A1*A(:,1), 0.4*A1*A(:,2), 0.4*A1*A(:,3), A2*A(:,4), A3*A(:,5)];

%generate Ptot with mismatch angles. 
for j=1:M
   P(j,1)=exp((j-1)*i*2*pi*d*sin(theta1+misang));
      Ptot(j,1) =  P(j,1);
      for f=1:2 
       %phi(f) = 2*pi*rand(1); %generate phase of multipathes paths. 
       P1(j,f) =exp((j-1)*i*2*pi*d*sin(DOA(f)+misang1));
       Ptot(j,1) = Ptot(j,1)+ 0.4*P1(j,f); 
   end
end

PL = [P(:,1) P1(:,1:f)]; %generalized steering vector matrix with m*ml dimension with mismatch
 
as = (P(:,1)/norm(P(:,1)))*M; %normalize the presumed steering vector for SOCP
%P(:,1) = as;
%Conventional  Beamformer 
R_v = 10^(Ndb/10)*eye(M,M);        %noise matrix
IR_v= inv(R_v);
pwc = 1/((P(:,1))'*IR_v*(P(:,1))); %output power 
Ko = P(:,1)'*IR_v*pwc;             %Optimal gain vector (Capon beamformer) 
itr1 = 0;
Tw1 = 1;
%adaptive beamforming start now (capon beamforming)
% initialaize the beamformer
wc = P(:,1)/M; % conventional beamformer;
%H = [A1*P(:,1), A2*P(:,2), A3*P(:,3)]; %generate mixing matrix which including the amplitudes
Pr = P(:,1);  %initialize the robust steering vector; 
%C =P(:,1); 
%Pr = zeros(M,1);
Gr = IR*Pr;   %initialize the gradient; 
%Pc1 = eye(M)-(C*C')/real((C'*C)); %Projection matrix for conventional capon beamforming
%Pc2 = eye(M)-(Pr*Pr')/real((Pr'*Pr)); 
for k = 1:N 
    r = X(:,k); %take one snapshot receiving vector
    Rs  = Ln*Rs + r*r';                     % autocorrelation matrix of recived signal  
    dem = real(1/(Ln+ r'*IR*r));            % 
    Kn = dem*IR*r;                          % Kalaman gain        
    IR = (1/Ln)*(IR - Kn*r'*IR);            % update inverse of Autocorrolation matrix 
   
    %IRs = inv(Rs);
    [U,D] = eig(Rs);                                    % get eigen vectors and values of autocorrelation matrix
    gm = real(diag(D));                                 % get eigenvalues in one vector
    z = U'*P(:,1);                                      % get vecotr to estimate the diagonal loading term
    landa1 = newton1(z,gm,ep2,P(:,1));                  % get the diagonal loading term by newton method
    Pd = P(:,1) - (inv(eye(M)+landa1*Rs))*P(:,1);       % get equivalent steering vector with uncertainities   
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % New robust detector similar to SOCP constraint and solved using
    % technique similar to the above one 
    Tw = newton2(z,gm,ep4,P(:,1),dl); % get norm of weight vector using newton like algorithm.
    if min(Tw)>0
    Tw1 = min(Tw);
    end
    ws = inv(Rs+(dl+(ep4/Tw1))*eye(M))*P(:,1); %weight vector of robust beamformer
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    as1 = P(:,1); %orginal steering vector 
    %as1 = Pr;
    if k==1
    wd = IR*as1;%/(real(as1'*IR*as1)); % initalize new robust detector.
    wd2 = IR*as1;
    end
    as2 = (as1- ep5*(wd/norm(wd))); %modified steering vector
    
    grd=Rs*wd;%-as2;
    grd1 = Rs*wd2;
    
    mu2 = alfa3*(norm(grd))^2/(real(grd'*Rs*grd)+0.000000001);
    mu3 = alfa4*(norm(grd1))^2/(real(grd1'*Rs*grd1)+0.000000001);
    %mu2 = 0.0001;
    wd1 = wd-mu2*grd; %initial weight vector without robustness
    
    wd11 = wd2-mu3*grd1;
    
    if real(wd1'*as1) < ep5*norm(wd1)+1 %check for robustness condition 
        A1 = mu2^2*((real(as2'*as1))^2-ep5^2*((norm(as2))^2));
        B1 = mu2*(real(wd1'*as1-1)*real(as2'*as1)-ep5^2*real(wd1'*as2));
        C1 = (real(wd1'*as1)-1)^2-ep5^2*norm(wd1)^2;
        landa3 = (-B1+(B1^2-A1*C1)^0.5)/A1; 
        wd = wd1+mu2*landa3*as2;
        itr1 = itr1 +1;
        QE = [QE; A1 B1 C1 landa3 norm(wd)];
    else
        wd = wd1;
        landa3 = 0;
    end
   
     chn = PL'*IR*PL;
  
    PL1 = PL-((wd11*ep6)/norm(wd11));  % get modified steering vector matrices 
  %  L0 = real(pinv(chn)*ep6');
  %if k==1  
  L0 = real(diag(pinv(chn)));
  %else
  %L0 = landa6;
  %end
     if any(real(wd11'*PL) < ep6*norm(wd11)+II)
         %options = optimset('tolfun', 1e-12);
  [landa6,FVAL,EXITFLAG,OUTPUT,JACOB] = fsolve(@(L)wcg (PL,PL1,wd11,mu3,ep6,L,II'), L0);
    wd2 = wd11+mu3*PL1*landa6;    
    iter = [iter;OUTPUT.iterations];
     else
    wd2 = wd11;
    landa6 = 0;
     end    
         
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   % SOCP Detector
    if mod(k-1,10)==0
    %as = (Pr/norm(Pr))*M;     
    %SOCP using SeDuMi software package 
       [wo] = robustbeam(Rs,as,ep3,diagl);
    end
  
    
    % chn = pinv(real (PL'*IR*PL)); %cost function
    %[Q1,e1] = eig(chn);
    %e1 = diag(e1);
    %q1 = Q1(:,find(e1==max(e1))); 
    
     Pt = (RP(:,1)+0.4*RP(:,2)+ 0.4*RP(:,3));   %real steering vector
    
    %wr = (IR*RP)*pinv(real(RP'*IR*RP))*g1;                     
    wr = (IR*RP)*pinv(real(RP'*IR*RP))*g1;                    % Benchmarck Capon beamforming
    wp = (IR*PL)*pinv(real(PL'*IR*PL))*g1;                     % conventional capon beamformer with multiple constraint
    %wg = (IR*P(:,1))/(real(P(:,1)'*IR*P(:,1)));   %conventional Capon with single constraint 
    wg = (IR*Pa)/(real(Pa'*IR*Pa));   %conventional Capon with single constraint   
    

    %wd = wd/norm(wd);
    %SINR
    SINRG(k,mc) = SINRF(wg,H,Ndb,1);             % SINR of standared capon beamformer with single constraint          
    SINRP(k,mc) = SINRFm(wp,H1,Ndb);             % SINR of standared capon beamformer   with multiple constrint        
    SINRD(k,mc) = SINRFm(wd,H1,Ndb);
    SINRS(k,mc) = SINRF(ws,H,Ndb,1);
    SINRO(k,mc) = SINRF(wo/norm(wo),H,Ndb,1);
    SINRR(k,mc) = SINRFm(wr,H1,Ndb);
    SINRD2(k,mc) = SINRFm(wd2,H1,Ndb);
    

end
end

%Smoothing and averaging over montcarlo simulation
%Butter worht smoothing Filter
[filt_num,filt_den] = butter(1,10^(-2));
%SINR
SINRG1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRG,2))));
SINRP1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRP,2))));
SINRD1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRD,2))));
SINRS1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRS,2))));
SINRO1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRO,2))));
SINRR1 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRR,2))));
SINRD2 = 10*log10(abs(filtfilt(filt_num,filt_den,mean(SINRD2,2))));


%Plot SINR

figure(3);
hsg = plot(1:N, SINRG1,'k',1:100:N,SINRG1(1:100:N),'d'); 
hold on;
hsp = plot(1:N, SINRP1,'k',1:100:N,SINRP1(1:100:N),'h'); 
hold on;
hsd = plot(1:N, SINRD1,'k',1:100:N,SINRD1(1:100:N),'*');
hold on;
hss = plot(1:N, SINRS1,'k',1:100:N,SINRS1(1:100:N),'^');
hold on;
hso = plot(1:N, SINRO1,'k',1:100:N,SINRO1(1:100:N),'o');
hold on;
hsd2 = plot(1:N, SINRD2,'k',1:100:N,SINRD2(1:100:N),'s');
hold on;
hsr = plot(1:N, SINRR1,'k',1:100:N,SINRR1(1:100:N),'+');



xlabel('Snapshot');
ylabel('SINR (dB)');
title(' Signal-to-Interference+Noise Ratio'); 
legend([hsg(2) hsp(2) hso(2) hss(2) hsd(2) hsd2(2) hsr(2)],'Benchmarck MVDR w. SBC ', 'Standared MVDR w. MBC', 'Robust MVDR-WC/SOCP','Robust MVDR-WC/EigDec','Robust MVDR-WC/Proposed','Robust MVDR-WC-MBC/Proposed','Benchmarck MVDR w. MBC');




