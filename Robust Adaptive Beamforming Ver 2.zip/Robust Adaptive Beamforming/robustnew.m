    function [Pr,Gr,G,it] =robustnew(IR,Pr,Ps,Gr,G,it,ep1)
    alfa1 = 0.008;                               % initalize the coffeiant of step-size 
    D = Gr + G;                               % update the previous gradient with Diagonal loading term
    mu = real((alfa1*D'*D)/(real(D'*IR*D)+0.00000001)); %update the step size
    Gr = IR'*Pr;                            % Calculate the gradient 
    pp1 = Pr-Ps;                        % it must satisfy the constraint 
    Pr1 =  Pr - mu*Gr;                        % update the robust steering vector w/t QI constraint  
    pp2 = Pr1-Ps;                       % calculate the difference with known steering vector
    if (norm(pp2)^2)> ep1                   % check for QC condition on pp vector1  
                cc = pp2'*pp2-ep1;                                    % positive
                bb = 2*mu*real(pp2'*pp1);                             % positive
                aa = (mu^2)*(pp1'*pp1);                               % positive
                landa = (bb-real(((bb^2)-(4*aa*cc))^0.5))/(2*aa);     % estimate diagonal Loading term
                Pr1 = Pr -mu*Gr-mu*landa*pp1;                         % apply Quadritic inquallity constrain
                G = landa*pp1;                                        % gradient of QC term to be added in advance  
                it = it+1;
            else
        G = 0;
    end
    Pr = Pr1;